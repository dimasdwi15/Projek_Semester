# java-dropdown-menu
![dropdown menu](https://user-images.githubusercontent.com/58245926/224536368-777a7057-dd50-4f72-a6ed-1c0b96b288ff.gif)
