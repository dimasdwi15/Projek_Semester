/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import javax.swing.DefaultComboBoxModel;
/**
 *
 * @author ASUS
 */
public class TransaksiBeli extends javax.swing.JPanel {
    Connection conn;
    Statement st;
    ResultSet rs;
    PreparedStatement pst;

    private DefaultTableModel tabmode;
    private DefaultTableModel tabmode2;
    private DefaultTableModel tabmode3;

    ;
    private String jumlahBarangText;
    private String stokText;


   
        
 
    public TransaksiBeli() {
        initComponents();
        
        aktif();
        autoIdBM();
        dataTable();
        tanggal();
        lebarKolom();
        isiComboSupplier();
        isiComboKodePart();
        setKoneksi();
        

        txtIdBarangMasuk.requestFocus();
        
    }
    public Connection setKoneksi(){
        try {
            // Pastikan driver MySQL sudah di-import
            Class.forName("com.mysql.jdbc.Driver");
            
            // Periksa kembali detail koneksi
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/rcollection", 
                "root", 
                ""
            );
            
            // Debugging: Cetak status koneksi
            System.out.println("Koneksi berhasil dibuat");
            
            return conn;
        } catch (ClassNotFoundException e) {
            System.err.println("Driver MySQL tidak ditemukan");
            JOptionPane.showMessageDialog(null, 
                "Driver MySQL tidak ditemukan: " + e.getMessage(), 
                "Error Koneksi", 
                JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            System.err.println("Gagal membuat koneksi:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Gagal membuat koneksi: " + e.getMessage(), 
                "Error Koneksi", 
                JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    

    private void aktif() {
        txtIdBarangMasuk.setEnabled(true);
        cbSupplier.setEnabled(true);
        cbKodePart.setEnabled(true);
        txtNamaPart.setEnabled(true);
        txtJumlahBarang.setEnabled(true);
    }

    protected void kosong() {
        txtIdBarangMasuk.setText(null);
        cbSupplier.setSelectedIndex(-1);
        cbKodePart.setSelectedIndex(-1);
        txtNamaPart.setText(null);
        txtJumlahBarang.setText(null);
        stok.setText(null);
    }

    protected void kosong2() {
        cbKodePart.setSelectedIndex(-1);
        txtNamaPart.setText(null);
        txtJumlahBarang.setText(null);
        stok.setText(null);
    }

    public void noTable() {
        int Baris = tabmode.getRowCount();
        for (int a = 0; a < Baris; a++) {
            String nomor = String.valueOf(a + 1);
            tabmode.setValueAt(nomor + ".", a, 0);
        }
    }

    public void tanggal() {
        Date dt = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-dd hh:mm:ss");
        DateTime.setText(sdf.format(dt));
    }
    
    
    private void isiComboSupplier() {
        try {
            // Pastikan koneksi database valid
            if (conn == null || conn.isClosed()) {
                setKoneksi(); // Pastikan method ini membuat koneksi
            }

            // Debugging: Cetak status koneksi
            System.out.println("Koneksi database: " + (conn != null ? "Berhasil" : "Gagal"));

            // Query untuk mendapatkan supplier
            String sql = "SELECT kode_supplier, nama_supplier FROM tb_supplier";
            try (PreparedStatement pst = conn.prepareStatement(sql);
                 ResultSet rs = pst.executeQuery()) {

                // Buat model ComboBox baru
                DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
                
                // Tambahkan pilihan default
                model.addElement("Pilih Supplier");

                // Tambahkan supplier dari database
                while (rs.next()) {
                    String kodeSupplier = rs.getString("kode_supplier");
                    
                    
                    // Debugging: Cetak setiap supplier yang ditemukan
                    System.out.println("Supplier ditemukan: " + kodeSupplier );
                    
                    model.addElement(kodeSupplier);
                }

                // Set model ke ComboBox
                cbSupplier.setModel(model);
                
                // Atur pilihan default
                cbSupplier.setSelectedIndex(0);
            }
        } catch (SQLException e) {
            // Tampilkan error dengan detail
            System.err.println("Error mengisi ComboBox Supplier:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Gagal memuat data supplier: " + e.getMessage(), 
                "Error Koneksi", 
                JOptionPane.ERROR_MESSAGE);
        }
}
    
    private void isiComboKodePart() {
    try {
        // Pastikan koneksi valid
        if (conn == null || conn.isClosed()) {
            setKoneksi();
        }

        String sql = "SELECT kode_barang, nama_barang, stok FROM data_barang";
        
        try (PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            // Bersihkan ComboBox sebelum mengisi
            cbKodePart.removeAllItems();
            
            // Tambahkan pilihan default
            cbKodePart.addItem("Pilih Barang");

            // Tambahkan barang dari database
            while (rs.next()) {
                String kodeBarang = rs.getString("kode_barang");
                String namaBarang = rs.getString("nama_barang");
                String stok = rs.getString("stok");
                
                // Format: Kode - Nama - Stok
                cbKodePart.addItem(kodeBarang);
            }

            // Atur pilihan default
            cbKodePart.setSelectedIndex(0);
        }
    } catch (SQLException e) {
        System.err.println("Error mengisi ComboBox Barang:");
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, 
            "Gagal memuat data barang: " + e.getMessage(), 
            "Error Koneksi", 
            JOptionPane.ERROR_MESSAGE);
    }
}

    
    private int jumlah() {
         String sql = "SELECT harga_beli FROM data_barang WHERE kode_barang = ?";
    try (PreparedStatement stat = conn.prepareStatement(sql)) {
        stat.setString(1, cbKodePart.getSelectedItem().toString());
        try (ResultSet hasil = stat.executeQuery()) {
            if (hasil.next()) {
                int harga_beli = hasil.getInt("harga_beli");
                int qty = Integer.parseInt(txtJumlahBarang.getText().trim());
                return qty * harga_beli;
            }
        }
    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error menghitung subtotal: " + e.getMessage());
    }
    return 0;
    }
    
    
    
    private int total() {
        String sql = "SELECT SUM(sub_total) AS sub_total FROM detail_brgmasuk WHERE no_faktur ="  + "'" + txtIdBarangMasuk.getText() + "'";
        try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                int total = hasil.getInt(1);
                return total;
            }
        }catch (Exception e) {
        }
        return 0;
    }
    
    private void updateTransaksi() {
        String sql = "UPDATE brg_masuk SET total =? WHERE brg_masuk.no_faktur=" + "'" +txtIdBarangMasuk.getText()+ "'";
        try {
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setInt(1, total());
            stat.executeUpdate();
        }catch (Exception e) {
        }
    }
    
    
    private int kurangStock() {
       String sql = "SELECT stok FROM data_barang WHERE kode_barang = ?";
    try (PreparedStatement stat = conn.prepareStatement(sql)) {
        if (cbKodePart.getSelectedItem() == null || cbKodePart.getSelectedItem().toString().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Pilih barang terlebih dahulu");
            return 0;
        }

        stat.setString(1, cbKodePart.getSelectedItem().toString());
        ResultSet hasil = stat.executeQuery();

        if (hasil.next()) {
            int stokdb = hasil.getInt("stok"); // Ambil stok dari database
            int qtyno;

            try {
                qtyno = Integer.parseInt(txtJumlahBarang.getText().trim());
                if (qtyno < 0) {
                    JOptionPane.showMessageDialog(null, "Jumlah barang tidak valid");
                    return 0;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Jumlah barang harus berupa angka");
                return 0;
            }

            return stokdb + qtyno; // Mengembalikan stok baru
        } else {
            JOptionPane.showMessageDialog(null, "Kode barang tidak ditemukan di database");
            return 0;
        }
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error pada kurangStock(): " + e.getMessage());
    }
    return 0; // Default jika terjadi error
    }
    
    private void stok() {
        String sql = "UPDATE data_barang SET stok = ? WHERE kode_barang = ?";
    try {
        if (conn == null || conn.isClosed()) {
            JOptionPane.showMessageDialog(null, "Koneksi database tidak tersedia");
            return;
        }

        if (cbKodePart.getSelectedItem() == null || cbKodePart.getSelectedItem().toString().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Pilih barang terlebih dahulu");
            return;
        }

        PreparedStatement stat = conn.prepareStatement(sql);
        stat.setInt(1, kurangStock()); // Perbarui stok
        stat.setString(2, cbKodePart.getSelectedItem().toString());
        int rowsAffected = stat.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Stok berhasil diperbarui");
        } else {
            JOptionPane.showMessageDialog(null, "Gagal memperbarui stok");
        }
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error pada stok(): " + e.getMessage());
    }
    }
    
    private void tampilTotal() {
        txtTotal.setText("Rp. " + total() + ",-");
    }
    
    //Autogenerate No Transaksi
    private void autoIdBM() {
        try {
            setKoneksi();
            java.sql.Statement stat = conn.createStatement();
            String sql = "select max(right (no_faktur,6)) as no from brg_masuk";
            ResultSet res = stat.executeQuery(sql);
            while (res.next()) {
                if (res.first() == false) {
                    txtIdBarangMasuk.setText("TR-000001");
                } else {
                    res.last();
                    int aut_id = res.getInt(1) + 1;
                    String no = String.valueOf(aut_id);
                    int no_jual = no.length();
                    // mengatur jumlah 0
                    for (int j = 0; j < 6 - no_jual; j++) {
                        no = "0" + no;
                    }
                    txtIdBarangMasuk.setText("TRB-" + no);
                }
            }
            res.close();
            stat.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan");
        }
    } 
    
    //Menampilkan Table Transaksi    
    public void dataTable() {
        Object[] Baris = {"No", "No Faktur", "Kode Barang", "Kode Supplier", "Nama Barang", "Jumlah Barang", "Sub Total", "Waktu", "Kasir"};
    tabmode = new DefaultTableModel(null, Baris);
    tabelBarangMasuk.setModel(tabmode);
    String sql = "SELECT brg_masuk.no_faktur, data_barang.kode_barang, brg_masuk.kode_supplier, data_barang.nama_barang, detail_brgmasuk.kuantitas, detail_brgmasuk.sub_total, brg_masuk.tanggal " +
                 "FROM brg_masuk " +
                 "JOIN detail_brgmasuk ON brg_masuk.no_faktur = detail_brgmasuk.no_faktur " +
                 "JOIN data_barang ON data_barang.kode_barang = detail_brgmasuk.kode_barang " +
                 "WHERE brg_masuk.no_faktur = ? " +
                 "ORDER BY brg_masuk.no_faktur ASC";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, txtIdBarangMasuk.getText());
        ResultSet hasil = stmt.executeQuery();
        while (hasil.next()) {
            String no_faktur = hasil.getString("no_faktur");
            String kode_barang = hasil.getString("kode_barang");
            String kode_supplier = hasil.getString("kode_supplier");
            String nama_barang = hasil.getString("nama_barang");
            String qty = hasil.getString("kuantitas");
            String sub_total = hasil.getString("sub_total");
            String tanggal = hasil.getString("tanggal");
            String[] data = {"", no_faktur, kode_barang, kode_supplier, nama_barang, qty, sub_total, tanggal, "KasirPlaceholder"};
            tabmode.addRow(data);
        }
        noTable();
    } catch (Exception e) {
        e.printStackTrace(); // Cetak error untuk debugging
    }
    }

  

    //Atur Lebar Table Transaksi
    public void lebarKolom() {
        TableColumn column;
        tabelBarangMasuk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabelBarangMasuk.getColumnModel().getColumn(0);
        column.setPreferredWidth(40);
        column = tabelBarangMasuk.getColumnModel().getColumn(1);
        column.setPreferredWidth(100);
        column = tabelBarangMasuk.getColumnModel().getColumn(2);
        column.setPreferredWidth(100);
        column = tabelBarangMasuk.getColumnModel().getColumn(3);
        column.setPreferredWidth(400);
        column = tabelBarangMasuk.getColumnModel().getColumn(4);
        column.setPreferredWidth(50);
        column = tabelBarangMasuk.getColumnModel().getColumn(5);
        column.setPreferredWidth(150);
        column = tabelBarangMasuk.getColumnModel().getColumn(6);
        column.setPreferredWidth(250);
        column = tabelBarangMasuk.getColumnModel().getColumn(7);
        column.setPreferredWidth(70);
    }

    
    
     private void tampilnamabarang() {
        try {
            String sql = "select nama_barang, stok"
                    + " from data_barang where kode_barang='" +cbKodePart.getSelectedItem().toString()+"'";
            Statement statement = (Statement) koneksi.getKoneksi().createStatement();
            java.sql.ResultSet res = statement.executeQuery(sql);
            while (res.next()){
                Object[] ob = new Object[3];
                ob [0] = res.getString(1);
                txtNamaPart.setText (res.getString("nama_barang"));
                stok.setText (res.getString("stok"));
            }
            res.close();
            statement.close();
        } catch(Exception e) {
            System.out.println(e.getMessage());
            }
    }

 private void tampilstok(){
     
 }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DateTime = new javax.swing.JLabel();
        btnbayar = new javax.swing.JButton();
        btnSimpan = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        btnBersih = new javax.swing.JButton();
        txtNamaSupplier = new javax.swing.JTextField();
        txtNamaPart = new javax.swing.JTextField();
        txtIdBarangMasuk = new javax.swing.JTextField();
        txtJumlahBarang = new javax.swing.JTextField();
        txtTotal = new javax.swing.JLabel();
        txbayar = new javax.swing.JTextField();
        cbSupplier = new javax.swing.JComboBox<>();
        txtkembali = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelBarangMasuk = new javax.swing.JTable();
        stok = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        cbKodePart = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        DateTime.setBackground(new java.awt.Color(255, 255, 255));
        add(DateTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 150, 30));

        btnbayar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/byar kecil.png"))); // NOI18N
        btnbayar.setContentAreaFilled(false);
        btnbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbayarActionPerformed(evt);
            }
        });
        add(btnbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 50, 30));

        btnSimpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/BtnSve.png"))); // NOI18N
        btnSimpan.setContentAreaFilled(false);
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });
        btnSimpan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnSimpanKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btnSimpanKeyReleased(evt);
            }
        });
        add(btnSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 480, 100, 70));

        btndelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/Btn Dlt.png"))); // NOI18N
        btndelete.setContentAreaFilled(false);
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });
        add(btndelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 480, 100, 60));

        btnTambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Salib.png"))); // NOI18N
        btnTambah.setBorder(null);
        btnTambah.setContentAreaFilled(false);
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });
        btnTambah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btnTambahKeyReleased(evt);
            }
        });
        add(btnTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 230, 40, 30));

        btnBersih.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/Btn Cln.png"))); // NOI18N
        btnBersih.setContentAreaFilled(false);
        btnBersih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBersihActionPerformed(evt);
            }
        });
        add(btnBersih, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 480, 90, 70));

        txtNamaSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaSupplierActionPerformed(evt);
            }
        });
        add(txtNamaSupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 232, 150, 30));

        txtNamaPart.setBorder(null);
        add(txtNamaPart, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 110, 160, 30));

        txtIdBarangMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdBarangMasukActionPerformed(evt);
            }
        });
        add(txtIdBarangMasuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 150, 30));

        txtJumlahBarang.setBorder(null);
        txtJumlahBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJumlahBarangActionPerformed(evt);
            }
        });
        txtJumlahBarang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtJumlahBarangKeyReleased(evt);
            }
        });
        add(txtJumlahBarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, 160, 30));

        txtTotal.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        txtTotal.setText("Rp. 0,-");
        add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 150, 30));

        txbayar.setBorder(null);
        txbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txbayarActionPerformed(evt);
            }
        });
        txbayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txbayarKeyPressed(evt);
            }
        });
        add(txbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 130, 30));

        cbSupplier.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSupplierActionPerformed(evt);
            }
        });
        add(cbSupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 150, -1));

        txtkembali.setBorder(null);
        add(txtkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 510, 130, 30));

        tabelBarangMasuk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelBarangMasuk);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 840, 120));

        stok.setBorder(null);
        add(stok, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 150, 160, 30));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Kode Barang");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 230, 130, 30));

        jPanel1.setBackground(new java.awt.Color(118, 98, 18));
        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 20, 100, 60));

        cbKodePart.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbKodePart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbKodePartActionPerformed(evt);
            }
        });
        add(cbKodePart, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 234, 150, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/menu/Transaksi Pembelian fix.png"))); // NOI18N
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 580));
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
   try {
        // Validasi input
        if (txtIdBarangMasuk.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Transaksi tidak boleh kosong");
            txtIdBarangMasuk.requestFocus();
            return;
        }

        if (cbSupplier.getSelectedItem() == null || 
            cbSupplier.getSelectedItem().toString().equals("Pilih Supplier")) {
            JOptionPane.showMessageDialog(null, "Pilih Supplier terlebih dahulu");
            cbSupplier.requestFocus();
            return;
        }

        if (cbKodePart.getSelectedItem() == null || 
            cbKodePart.getSelectedItem().toString().equals("Pilih Barang")) {
            JOptionPane.showMessageDialog(null, "Pilih Barang terlebih dahulu");
            cbKodePart.requestFocus();
            return;
        }

        // Validasi jumlah barang
        if (txtJumlahBarang.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Jumlah barang tidak boleh kosong");
            txtJumlahBarang.requestFocus();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(txtJumlahBarang.getText().trim());
            if (qty <= 0) {
                JOptionPane.showMessageDialog(null, "Jumlah barang harus lebih dari 0");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Jumlah barang harus berupa angka");
            return;
        }

        // Pastikan koneksi tersedia
        if (conn == null || conn.isClosed()) {
            JOptionPane.showMessageDialog(null, "Koneksi database tidak tersedia");
            return;
        }

        // Query Insert
        String sql = "INSERT INTO detail_brgmasuk (no_faktur, kode_barang, kuantitas, sub_total, bayar, kembali) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stat = conn.prepareStatement(sql)) {
            stat.setString(1, txtIdBarangMasuk.getText().trim());
            stat.setString(2, cbKodePart.getSelectedItem().toString());
            stat.setInt(3, qty);
            
            int subTotal = jumlah(); // Hitung subtotal
            stat.setInt(4, subTotal);
            
            stat.setString(5, "0"); // Bayar default 0
            stat.setString(6, "0"); // Kembali default 0
            
            int rowsAffected = stat.executeUpdate();
            
            if (rowsAffected > 0) {
                  // Tambahkan logika update stok di sini
                try {
                    // Pastikan field tidak kosong
                    
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Silakan masukkan angka yang valid untuk stok dan jumlah");
                }
                
                
                
                // Update stok
                stok();
                
                // Reset jumlah barang  menjadi 0
                txtJumlahBarang.setText("0");

                
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
                
                // Refresh tampilan
                dataTable();
                lebarKolom();
                tampilTotal();
                updateTransaksi();
                jumlah();
                // Set fokus
                cbKodePart.requestFocus();
            } else {
                JOptionPane.showMessageDialog(null, "Gagal menyimpan data");
            }
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error database: " + e.getMessage());
    }
        
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbayarActionPerformed
         // TODO add your handling code here:
        String sql = "UPDATE detail_brgmasuk SET bayar =?, kembali =? WHERE detail_brgmasuk.no_faktur=" + "'" +txtIdBarangMasuk.getText()+ "'";
            try {
                //Insert data detail transaksi
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.setString(1, txbayar.getText());
                stat.setString(2, txtkembali.getText());
                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Pembayaran Berhasil Disimpan pada Detail Transaksi");
                txbayar.setEnabled(true);
                txtkembali.setEnabled(true);
                dataTable();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan" + e);
            }
    }//GEN-LAST:event_btnbayarActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        // TODO add your handling code here:
         if (txtIdBarangMasuk.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "No Transaksi tidak boleh kosong");
            txtIdBarangMasuk.requestFocus();
        } else if (cbSupplier.getSelectedItem().toString().equals("")) {
            JOptionPane.showMessageDialog(null, "Kasir tidak boleh kosong");
            cbSupplier.requestFocus();
        } else if (cbKodePart.getSelectedItem().toString().equals("")) {
            JOptionPane.showMessageDialog(null, "Kode Barang tidak boleh kosong");
            cbKodePart.requestFocus();
        } else if (txtNamaPart.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Nama Barang tidak boleh kosong");
            txtNamaPart.requestFocus();
        } else if (txtJumlahBarang.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Jumlah Barang tidak boleh kosong");
            txtJumlahBarang.requestFocus();
        } else {
            String sqll = "INSERT INTO brg_masuk values (?,?,?,?)";
            Date dt = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-dd hh:mm:ss");
            String tanggal = String.valueOf(sdf.format(dt));
            String total = "0";
            try {
                 try {
        // Pastikan kedua field tidak kosong
        if (!txtJumlahBarang.getText().trim().isEmpty() && !stok.getText().trim().isEmpty()) {
            // Validasi input adalah angka
            int stokSaatIni = Integer.parseInt(stok.getText().trim());
            int jumlah;
            
            try {
                jumlah = Integer.parseInt(txtJumlahBarang.getText().trim());
                
                // Pastikan jumlah positif
                if (jumlah < 0) {
                    JOptionPane.showMessageDialog(null, "Jumlah harus angka positif");
                    txtJumlahBarang.setText("");
                    return;
                }
                
                // Hitung stok baru
                int stokBaru = stokSaatIni + jumlah;
                
                // Perbarui TextField stok
                stok.setText(String.valueOf(stokBaru));
                
                // JANGAN mereset txtJumlahBarang ke 0 
                            
                // Biarkan pengguna mengontrol input
                
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Masukkan angka yang valid untuk jumlah");
                txtJumlahBarang.setText("");
            }
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Stok atau jumlah tidak valid");
    }
                //Insert data transaksi
                PreparedStatement state = conn.prepareStatement(sqll);
                state.setString(1, txtIdBarangMasuk.getText());
                state.setString(2, cbSupplier.getSelectedItem().toString());
                state.setString(3, tanggal);
                state.setString(4, total);

                state.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan di Daatabase");
                dataTable();
                lebarKolom();
                txtIdBarangMasuk.setEnabled(true);
                cbSupplier.setEnabled(true);
                txtJumlahBarang.requestFocus();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan" + e);
            }
        }
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnBersihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBersihActionPerformed
        // TODO add your handling code here:
        autoIdBM();
        tanggal();
        dataTable();
        lebarKolom();
        txtIdBarangMasuk.requestFocus();
        cbSupplier.setSelectedIndex(-1);
        cbKodePart.setSelectedIndex(-1);
        txtNamaPart.setText(null);
        txtJumlahBarang.setText(null);
        txtNamaSupplier.setText(null);
        txbayar.setText(null);
        txtkembali.setText(null);
        txtTotal.setText("Rp. 0,-");
        stok.setText(null);
    }//GEN-LAST:event_btnBersihActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        // TODO add your handling code here:
        int ok = JOptionPane.showConfirmDialog(null, " Apakah Anda Yakin Ingin "
            + "Menghapus Data", "Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
        if (ok == 0) {
            String sql = "delete from detail_brgmasuk where no_faktur ='" + txtIdBarangMasuk.getText() + "'";
            String sqll = "delete from brg_masuk where no_faktur ='" + txtIdBarangMasuk.getText() + "'";
            try {
                PreparedStatement stat = conn.prepareStatement(sql);
                PreparedStatement state = conn.prepareStatement(sqll);
                stat.executeUpdate();
                state.executeUpdate();

                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
                kosong2();
                tanggal();
                dataTable();
                lebarKolom();
                cbSupplier.requestFocus();
                txtTotal.setText("Rp. " + 0 + ",-");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Dihapus" + e);
            }
        }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void txbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txbayarActionPerformed
        // TODO add your handling code here:
        int total,bayar,Kembali;
        
        total = Integer.valueOf(txtTotal.getText());
        bayar = Integer.valueOf(txbayar.getText());
        
        if (total>bayar){
            JOptionPane.showMessageDialog(null, "Uang Yang Anda Bayarkan Kurang!");
        }else{
            Kembali = bayar - total;
            txtkembali.setText(String.valueOf(Kembali));
        }
    }//GEN-LAST:event_txbayarActionPerformed

    private void txbayarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txbayarKeyPressed
        // TODO add your handling code here:
         if(evt.getKeyCode()== KeyEvent.VK_ENTER){
            int total = Integer.parseInt(txtTotal.getText().replace("Rp.", "").replaceAll("\\s+", "").replace(",-", ""));
            int pay = Integer.parseInt(txbayar.getText());
            if (total > pay){
                JOptionPane.showMessageDialog(null, "Uang yang dibayarkan kurang");
            }else {
                int kembalian = pay - total;
                txtkembali.setText(String.valueOf(kembalian));}
      
        }
    }//GEN-LAST:event_txbayarKeyPressed

    private void txtNamaSupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaSupplierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaSupplierActionPerformed

    private void txtIdBarangMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdBarangMasukActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdBarangMasukActionPerformed

    private void txtJumlahBarangKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtJumlahBarangKeyReleased
 
    }//GEN-LAST:event_txtJumlahBarangKeyReleased

    private void txtJumlahBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJumlahBarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtJumlahBarangActionPerformed

    private void cbSupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSupplierActionPerformed
      String selectedSupplier = (String) cbSupplier.getSelectedItem();
    
    if (selectedSupplier == null || selectedSupplier.equals("Pilih Supplier")) {
        txtNamaSupplier.setText("");
        return;
    }

    try {
        // Pisahkan kode supplier
        String kodeSupplier = selectedSupplier.split(" - ")[0];
        
        // Query untuk mendapatkan nama supplier
        String sql = "SELECT nama_supplier FROM tb_supplier WHERE kode_supplier = ?";
        
        // Gunakan try-with-resources untuk PreparedStatement
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, kodeSupplier);
            
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    // Set nama supplier ke TextField
                    txtNamaSupplier.setText(rs.getString("nama_supplier"));
                    
                    System.out.println("Supplier terpilih: " + rs.getString("nama_supplier"));
                } else {
                    // Tampilkan pesan jika supplier tidak ditemukan
                    JOptionPane.showMessageDialog(null, 
                        "Supplier tidak ditemukan.", 
                        "Peringatan", 
                        JOptionPane.WARNING_MESSAGE);
                }
            }
        }
    } catch (SQLException e) {
        System.err.println("Error saat memilih supplier:");
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, 
            "Gagal memuat detail supplier: " + e.getMessage(), 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
    
}

    }//GEN-LAST:event_cbSupplierActionPerformed

    private void btnTambahKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnTambahKeyReleased
        try {
        // Pastikan kedua field tidak kosong
        if (!txtJumlahBarang.getText().trim().isEmpty() && !stok.getText().trim().isEmpty()) {
            // Validasi input adalah angka
            int stokSaatIni = Integer.parseInt(stok.getText().trim());
            int jumlah;
            
            try {
                jumlah = Integer.parseInt(txtJumlahBarang.getText().trim());
                
                // Pastikan jumlah positif
                if (jumlah < 0) {
                    JOptionPane.showMessageDialog(null, "Jumlah harus angka positif");
                    txtJumlahBarang.setText("");
                    return;
                }
                
                // Hitung stok baru
                int stokBaru = stokSaatIni + jumlah;
                
                // Perbarui TextField stok
                stok.setText(String.valueOf(stokBaru));
                
                // JANGAN mereset txtJumlahBarang ke 0 
                // Biarkan pengguna mengontrol input
                
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Masukkan angka yang valid untuk jumlah");
                txtJumlahBarang.setText("");
            }
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Stok atau jumlah tidak valid");
    }
    }//GEN-LAST:event_btnTambahKeyReleased

    private void cbKodePartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbKodePartActionPerformed
        // TODO add your handling code here:
        String selectedBarang = (String) cbKodePart.getSelectedItem();

        // Hindari proses jika pilihan default atau null
        if (selectedBarang == null || selectedBarang.equals("Pilih Barang")) {
            txtNamaPart.setText("");
            stok.setText("");
            return;
        }

        try {
            // Pisahkan kode barang
            String kodeBarang = selectedBarang.split(" - ")[0];

            // Query untuk mendapatkan detail barang
            String sql = "SELECT nama_barang, stok FROM data_barang WHERE kode_barang = ?";
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, kodeBarang);
                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        // Set nama barang dan stok
                        txtNamaPart.setText(rs.getString("nama_barang"));
                        stok.setText(rs.getString("stok"));

                        // Debugging: Cetak detail barang yang dipilih
                        System.out.println("Barang terpilih: " + rs.getString("nama_barang"));
                        System.out.println("Stok: " + rs.getString("stok"));
                    } else {
                        // Tampilkan pesan jika barang tidak ditemukan
                        JOptionPane.showMessageDialog(null,
                            "Barang tidak ditemukan.",
                            "Peringatan",
                            JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saat memilih barang:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Gagal memuat detail barang: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cbKodePartActionPerformed

    private void btnSimpanKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSimpanKeyReleased

    }//GEN-LAST:event_btnSimpanKeyReleased

    private void btnSimpanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSimpanKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnSimpanKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DateTime;
    private javax.swing.JButton btnBersih;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnbayar;
    private javax.swing.JButton btndelete;
    private javax.swing.JComboBox<String> cbKodePart;
    private javax.swing.JComboBox<String> cbSupplier;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField stok;
    private javax.swing.JTable tabelBarangMasuk;
    private javax.swing.JTextField txbayar;
    private javax.swing.JTextField txtIdBarangMasuk;
    private javax.swing.JTextField txtJumlahBarang;
    private javax.swing.JTextField txtNamaPart;
    private javax.swing.JTextField txtNamaSupplier;
    private javax.swing.JLabel txtTotal;
    private javax.swing.JTextField txtkembali;
    // End of variables declaration//GEN-END:variables
}
