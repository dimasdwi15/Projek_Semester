/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import static component.koneksi.getKoneksi;
import javax.swing.DefaultComboBoxModel;

public class TransaksiJual_1 extends javax.swing.JPanel {
    Connection conn;

    private DefaultTableModel tabmode;
    private DefaultTableModel tabmode2;
    private DefaultTableModel tabmode3;
    JasperReport JasRep;
    JasperPrint JasPri;
    Map param = new HashMap();
    JasperDesign JasDes;

    private void aktif() {
        txtnotransaksi.setEnabled(true);
       // txtKasir.setEnabled(true);
        cbKodePart.setEnabled(true);
        txtNamaPart.setEnabled(true);
        txtJumlahBarang.setEnabled(true);
    }

    protected void kosong() {
        txtnotransaksi.setText(null);
        
        cbKodePart.setSelectedIndex(-1);
        txtNamaPart.setText(null);
        txtJumlahBarang.setText(null);
    }

    protected void kosong2() {
       cbKodePart.setSelectedIndex(-1);
        txtNamaPart.setText(null);
        txtJumlahBarang.setText(null);
        stok.setText(null);
    }

    public void noTable() {
        int Baris = tabmode.getRowCount();
        for (int a = 0; a < Baris; a++) {
            String nomor = String.valueOf(a + 1);
            tabmode.setValueAt(nomor + ".", a, 0);
        }
    }
    
    //PENGATURAN TANGGAL
    public void tanggal() {
        Date dt = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-dd hh:mm:ss");
        DateTime.setText(sdf.format(dt));
    }
    
    //MENENTUKAN SUBTOTAL HARGA
    private int jumlah() {
        String sql = "SELECT harga_jual FROM data_barang WHERE kode_barang =" + "'" +cbKodePart.getSelectedItem().toString() + "'";
        try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                String qty = txtJumlahBarang.getText();
                int harga_jual = hasil.getInt(1);
                int qtyy = Integer.parseInt(qty);
                int jumlah = qtyy * harga_jual;
                return jumlah;
            }
        } catch (Exception e) {
        }
        return 0;
    }
    
    //MENENTUKAN TOTAL HARGA
    private int total() {
        String sql = "SELECT SUM(sub_total) AS sub_total FROM detail_brgkeluar WHERE no_transaksi ="  + "'" + txtnotransaksi.getText() + "'";
        try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                int total = hasil.getInt(1);
                return total;
            }
        }catch (Exception e) {
        }
        return 0;
    }
    
    private void updateTransaksi() {
        String sql = "UPDATE brg_keluar SET total =? WHERE brg_keluar.no_transaksi=" + "'" +txtnotransaksi.getText()+ "'";
        try {
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setInt(1, total());
            stat.executeUpdate();
        }catch (Exception e) {
        }
    }
    
    private int kurangStock() {
        String sql = "SELECT stok FROM data_barang WHERE kode_barang =" + "'" + cbKodePart.getSelectedItem().toString() + "'";
        try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                int stokdb = hasil.getInt(1);
                String qty = txtJumlahBarang.getText();
                int qtyno = Integer.parseInt(qty);
                int nilai = stokdb - qtyno;
                return nilai;
            }
        }catch (Exception e) {
        }
        return 0;
    }
    
    private void stok() {
        String sql = "UPDATE data_barang SET stok =? WHERE data_barang.kode_barang=" + "'" +cbKodePart.getSelectedItem().toString()+ "'";
        try {
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setInt(1, kurangStock());
            stat.executeUpdate();
        }catch (Exception e) {
        }
    }
    
    private void tampilTotal() {
        txtTotal.setText("Rp. " + total() + ",-");
    }
    
    //Autogenerate No Transaksi
    private void autoIdBM() {
        try {
            Connection con =  koneksi.getKoneksi();
            java.sql.Statement stat = con.createStatement();
            String sql = "select max(right (no_transaksi,6)) as no from brg_keluar";
            ResultSet res = stat.executeQuery(sql);
            while (res.next()) {
                if (res.first() == false) {
                    txtnotransaksi.setText("TR-000001");
                } else {
                    res.last();
                    int aut_id = res.getInt(1) + 1;
                    String no = String.valueOf(aut_id);
                    int no_jual = no.length();
                    // mengatur jumlah 0
                    for (int j = 0; j < 6 - no_jual; j++) {
                        no = "0" + no;
                    }
                    txtnotransaksi.setText("TR-" + no);
                }
            }
            res.close();
            stat.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan");
        }
    } 
    
    //Menampilkan Table Transaksi    
    public void dataTable() {
        Object[] Baris = {"No", "No Transaksi", "Kode Barang", "Nama Barang", "Jumlah Barang", "Sub Total", "Waktu", "Kasir"};
        tabmode = new DefaultTableModel(null, Baris);
        tabelBarangMasuk.setModel(tabmode);
         String sql = "SELECT brg_keluar.no_transaksi, data_barang.kode_barang,brg_keluar.id, data_barang.nama_barang,  detail_brgkeluar.kuantitas, detail_brgkeluar.sub_total, brg_keluar.tanggal FROM brg_keluar JOIN detail_brgkeluar ON  brg_keluar.no_transaksi = detail_brgkeluar.no_transaksi JOIN data_barang ON data_barang.kode_barang = detail_brgkeluar.kode_barang  WHERE brg_keluar.no_transaksi=" + "'" + txtnotransaksi.getText() + "'" +"ORDER BY brg_keluar.no_transaksi ASC;";
        try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                String no_transaksi = hasil.getString("brg_keluar.no_transaksi");
                String kode_barang = hasil.getString("data_barang.kode_barang");
                String id_user = hasil.getString("brg_keluar.id");
                String nama_barang = hasil.getString("data_barang.nama_barang");
                String qty = hasil.getString("detail_brgkeluar.kuantitas");
                String sub_total = hasil.getString("detail_brgkeluar.sub_total");
                String tanggal = hasil.getString("brg_keluar.tanggal");
                String[] data = {"", no_transaksi, kode_barang, nama_barang, qty, sub_total, tanggal, id_user};
                tabmode.addRow(data);
                noTable();
            }
        } catch (Exception e) {
        }
    }

 
  
    //Atur Lebar Table Transaksi
    public void lebarKolom() {
        TableColumn column;
        tabelBarangMasuk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabelBarangMasuk.getColumnModel().getColumn(0);
        column.setPreferredWidth(40);
        column = tabelBarangMasuk.getColumnModel().getColumn(1);
        column.setPreferredWidth(100);
        column = tabelBarangMasuk.getColumnModel().getColumn(2);
        column.setPreferredWidth(100);
        column = tabelBarangMasuk.getColumnModel().getColumn(3);
        column.setPreferredWidth(400);
        column = tabelBarangMasuk.getColumnModel().getColumn(4);
        column.setPreferredWidth(50);
        column = tabelBarangMasuk.getColumnModel().getColumn(5);
        column.setPreferredWidth(150);
        column = tabelBarangMasuk.getColumnModel().getColumn(6);
        column.setPreferredWidth(250);
        column = tabelBarangMasuk.getColumnModel().getColumn(7);
        column.setPreferredWidth(70);
    }
    
    public Connection setKoneksi(){
        try {
            // Pastikan driver MySQL sudah di-import
            Class.forName("com.mysql.jdbc.Driver");
            
            // Periksa kembali detail koneksi
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/rcollection", 
                "root", 
                ""
            );
            
            // Debugging: Cetak status koneksi
            System.out.println("Koneksi berhasil dibuat");
            
            return conn;
        } catch (ClassNotFoundException e) {
            System.err.println("Driver MySQL tidak ditemukan");
            JOptionPane.showMessageDialog(null, 
                "Driver MySQL tidak ditemukan: " + e.getMessage(), 
                "Error Koneksi", 
                JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            System.err.println("Gagal membuat koneksi:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Gagal membuat koneksi: " + e.getMessage(), 
                "Error Koneksi", 
                JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    private void isiComboKodePart() {
    try {
        // Pastikan koneksi valid
        if (conn == null || conn.isClosed()) {
            setKoneksi();
        }

        String sql = "SELECT kode_barang, nama_barang, stok FROM data_barang";
        
        try (PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            // Bersihkan ComboBox sebelum mengisi
            cbKodePart.removeAllItems();
            
            // Tambahkan pilihan default
            cbKodePart.addItem("Pilih Barang");

            // Tambahkan barang dari database
            while (rs.next()) {
                String kodeBarang = rs.getString("kode_barang");
                String namaBarang = rs.getString("nama_barang");
                String stok = rs.getString("stok");
                
                // Format: Kode - Nama - Stok
                cbKodePart.addItem(kodeBarang);
            }

            // Atur pilihan default
            cbKodePart.setSelectedIndex(0);
        }
    } catch (SQLException e) {
        System.err.println("Error mengisi ComboBox Barang:");
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, 
            "Gagal memuat data barang: " + e.getMessage(), 
            "Error Koneksi", 
            JOptionPane.ERROR_MESSAGE);
    }
}

    //Pencarian Kasir
    
    private void tampilnamabarang() 
{
    try {
            String sql = "select nama_barang, stok"
                    + " from data_barang where kode_barang='" +cbKodePart.getSelectedItem().toString()+"'";
            Statement statement = (Statement) koneksi.getKoneksi().createStatement();
            java.sql.ResultSet res = statement.executeQuery(sql);
            while (res.next()){
                Object[] ob = new Object[3];
                ob [0] = res.getString(1);
                txtNamaPart.setText (res.getString("nama_barang"));
                stok.setText (res.getString("stok"));
            }
            res.close();
            statement.close();
    } catch(Exception e) {
            System.out.println(e.getMessage());
    }
}
 /**private void tampilnamakaryawan() 
{
    try {
            String sql = "select nama from tb_user where id='" +txtKasir.getText()+"'";
            Statement statement = (Statement) koneksi.getKoneksi().createStatement();
            java.sql.ResultSet res = statement.executeQuery(sql);
            while (res.next()){
                Object[] ob = new Object[3];
                ob [0] = res.getString(1);
                kasir.setText (res.getString("nama"));
            }
            res.close();
            statement.close();
    } catch(Exception e) {
            System.out.println(e.getMessage());
    }
}**/
    public TransaksiJual_1() {
        initComponents();
        aktif();
        autoIdBM();
        dataTable();
        tanggal();
        lebarKolom();
        isiComboKodePart();
        setKoneksi();
        
        txtnotransaksi.requestFocus();
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnbayar = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        cbKodePart = new javax.swing.JComboBox<>();
        DateTime = new javax.swing.JLabel();
        txtNamaPart = new javax.swing.JTextField();
        stok = new javax.swing.JTextField();
        txtTotal = new javax.swing.JLabel();
        txtJumlahBarang = new javax.swing.JTextField();
        txbayar = new javax.swing.JTextField();
        txkembali = new javax.swing.JTextField();
        txtnotransaksi = new javax.swing.JTextField();
        btnSimpan = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        btnBersih = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelBarangMasuk = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(924, 576));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnbayar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/byar kecil.png"))); // NOI18N
        btnbayar.setContentAreaFilled(false);
        btnbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbayarActionPerformed(evt);
            }
        });
        add(btnbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 50, 30));

        btnTambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Salib.png"))); // NOI18N
        btnTambah.setContentAreaFilled(false);
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });
        add(btnTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 220, 40, 30));

        cbKodePart.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbKodePart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbKodePartActionPerformed(evt);
            }
        });
        add(cbKodePart, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 220, 150, 30));

        DateTime.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                DateTimePropertyChange(evt);
            }
        });
        add(DateTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 140, 30));

        txtNamaPart.setBorder(null);
        txtNamaPart.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNamaPartKeyPressed(evt);
            }
        });
        add(txtNamaPart, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 100, 140, 30));

        stok.setBorder(null);
        add(stok, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 140, 140, 30));

        txtTotal.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(255, 52, 52));
        txtTotal.setText("Rp. 0,-");
        add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 150, 30));

        txtJumlahBarang.setBorder(null);
        add(txtJumlahBarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 180, 140, 30));

        txbayar.setBorder(null);
        txbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txbayarActionPerformed(evt);
            }
        });
        txbayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txbayarKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txbayarKeyReleased(evt);
            }
        });
        add(txbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 130, 30));

        txkembali.setBorder(null);
        add(txkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 510, 130, 30));

        txtnotransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnotransaksiActionPerformed(evt);
            }
        });
        add(txtnotransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 140, 30));

        btnSimpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/BtnSve.png"))); // NOI18N
        btnSimpan.setContentAreaFilled(false);
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });
        add(btnSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 490, 100, 60));

        btndelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/Btn Dlt.png"))); // NOI18N
        btndelete.setContentAreaFilled(false);
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });
        add(btndelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 490, 100, 60));

        btnBersih.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UI/Btn Cln.png"))); // NOI18N
        btnBersih.setContentAreaFilled(false);
        btnBersih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBersihActionPerformed(evt);
            }
        });
        add(btnBersih, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 490, 100, 60));

        tabelBarangMasuk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelBarangMasuk);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 850, 120));

        jPanel1.setBackground(new java.awt.Color(118, 98, 18));
        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 0, 90, 80));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/menu/TransaksiJualAdmin.png"))); // NOI18N
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // code Menambahkan pada coloumn Detail Transaksi Jual:
        Integer qty,jmlstock;
        

        qty = Integer.parseInt(txtJumlahBarang.getText());
        jmlstock = Integer.parseInt(stok.getText());
        

        if (txtnotransaksi.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "No Transaksi tidak boleh kosong");
            txtnotransaksi.requestFocus();
            /**
        } else if (txtKasir.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Kasir tidak boleh kosong");
            txtKasir.requestFocus();
        **/
        } else if (qty > jmlstock){
            JOptionPane.showMessageDialog(null, "Stok anda kurang");
        }else {
            String sql = "INSERT INTO detail_brgkeluar values (?,?,?,?,?,?)";
            Date dt = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-dd hh:mm:ss");
            String tanggal = String.valueOf(sdf.format(dt));
            String bayar = "0";
            String kembali = "0";
            try {
                //Insert data detail transaksi
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.setString(1, txtnotransaksi.getText());
                stat.setString(2, cbKodePart.getSelectedItem().toString());
                stat.setString(3, txtJumlahBarang.getText());
                stat.setInt(4, jumlah());
                stat.setString(5, bayar);
                stat.setString(6, kembali);
                stat.executeUpdate();
                stok();
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan pada Detail Transaksi");
                dataTable();
                kosong2();
                lebarKolom();
                txtnotransaksi.setEnabled(true);
              //  txtKasir.setEnabled(true);
                cbKodePart.requestFocus();
                tampilTotal();
                updateTransaksi();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan" + e);
            }
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        // code Menambahkan pada coloumn Transaksi Jual:
         if (txtnotransaksi.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "No Transaksi tidak boleh kosong");
            txtnotransaksi.requestFocus();
     /**   } else if (txtKasir.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Kasir tidak boleh kosong");
            txtKasir.requestFocus(); **/
        } else if (cbKodePart.getSelectedItem().toString().equals("")) {
            JOptionPane.showMessageDialog(null, "Kode Barang tidak boleh kosong");
            cbKodePart.requestFocus();
        } else if (txtNamaPart.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Nama Barang tidak boleh kosong");
            txtNamaPart.requestFocus();
        } else if (txtJumlahBarang.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Jumlah Barang tidak boleh kosong");
            txtJumlahBarang.requestFocus();
        } else {
            String sqll = "INSERT INTO brg_keluar values (?,?,?,?)";
            Date dt = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-dd hh:mm:ss");
            String tanggal = String.valueOf(sdf.format(dt));
            String total = "0";
            
            try {
                //Insert data transaksi
                PreparedStatement state = conn.prepareStatement(sqll);
                state.setString(1, txtnotransaksi.getText());
              //  state.setString(2, txtKasir.getText());
                state.setString(2, tanggal);
                state.setString(3, total);
               
                state.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan di Transaksi");
                dataTable();
                lebarKolom();
                txtnotransaksi.setEnabled(true);
              //  txtKasir.setEnabled(true);
                txtJumlahBarang.requestFocus();
                tampilTotal();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan" + e);
            }
        }
        
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbayarActionPerformed
        // TODO add your handling code here:
        String sql = "UPDATE detail_brgkeluar SET bayar =?, kembali =? WHERE detail_brgkeluar.no_transaksi=" + "'" +txtnotransaksi.getText()+ "'";
            try {
                //Insert data detail transaksi
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.setString(1, txbayar.getText());
                stat.setString(2, txkembali.getText());
                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Pembayaran Berhasil Disimpan pada Detail Transaksi");
                txbayar.setEnabled(true);
                txkembali.setEnabled(true);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan" + e);
            }
    }//GEN-LAST:event_btnbayarActionPerformed

    private void btnBersihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBersihActionPerformed
        // TODO add your handling code here:
         autoIdBM();
        tanggal();
        dataTable();
        lebarKolom();
        txtnotransaksi.requestFocus();
     //   txtKasir.setText(null);
        cbKodePart.setSelectedIndex(-1);
        txtNamaPart.setText(null);
        txtJumlahBarang.setText(null);
        txbayar.setText(null);
        txkembali.setText(null);
        txtTotal.setText("Rp. 0,-");
        stok.setText(null);
    }//GEN-LAST:event_btnBersihActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        // Confirm deletion with the user
    int ok = JOptionPane.showConfirmDialog(null,
            "Apakah Anda Yakin Ingin Menghapus Data?",
            "Konfirmasi Dialog",
            JOptionPane.YES_NO_OPTION);
    
    if (ok == JOptionPane.YES_OPTION) {
        String sqlDetail = "DELETE FROM detail_brgkeluar WHERE no_transaksi = ?";
        String sqlMain = "DELETE FROM brg_keluar WHERE no_transaksi = ?";
        
        try (PreparedStatement statDetail = conn.prepareStatement(sqlDetail);
             PreparedStatement statMain = conn.prepareStatement(sqlMain)) {
            
            conn.setAutoCommit(false); // Start transaction
            
            // Set parameters for both queries
            String noTransaksi = txtnotransaksi.getText();
            statDetail.setString(1, noTransaksi);
            statMain.setString(1, noTransaksi);
            
            // Execute queries
            int rowsDetail = statDetail.executeUpdate();
            int rowsMain = statMain.executeUpdate();
            
            if (rowsDetail > 0 || rowsMain > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
            } else {
                JOptionPane.showMessageDialog(null, "Tidak ada data yang dihapus. Periksa no_transaksi.");
            }
            
            conn.commit(); // Commit transaction
            kosong2();
            tanggal();
            dataTable();
            lebarKolom();
        //    txtKasir.requestFocus();
            
        } catch (SQLException e) {
            try {
                conn.rollback(); // Rollback transaction on error
            } catch (SQLException rollbackEx) {
                JOptionPane.showMessageDialog(null, "Rollback gagal: " + rollbackEx.getMessage());
            }
            JOptionPane.showMessageDialog(null, "Data Gagal Dihapus: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true); // Restore default auto-commit behavior
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Gagal mengembalikan auto-commit: " + ex.getMessage());
            }
        }
    }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void txbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txbayarActionPerformed
        // TODO add your handling code here:
        int total,bayar,kembali;
        
        total = Integer.valueOf(txtTotal.getText());
        bayar = Integer.valueOf(txbayar.getText());
        
        if (total>bayar){
            JOptionPane.showMessageDialog(null, "Uang Yang Anda Bayarkan Kurang!");
        }else{
            kembali = bayar - total;
            txkembali.setText(String.valueOf(kembali));
        }
    }//GEN-LAST:event_txbayarActionPerformed

    private void txtNamaPartKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNamaPartKeyPressed
        // TODO add your handling code here:
         tampilnamabarang() ;
    }//GEN-LAST:event_txtNamaPartKeyPressed

    private void txbayarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txbayarKeyPressed
        // TODO add your handling code here:
        int total,bayar,kembali;
        
        total = Integer.valueOf(txtTotal.getText());
        bayar = Integer.valueOf(txbayar.getText());
        
        if (total>bayar){
            JOptionPane.showMessageDialog(null, "Uang Yang Anda Bayarkan Kurang!");
        }else{
            kembali = bayar - total;
            txkembali.setText(String.valueOf(kembali));
        }
    }//GEN-LAST:event_txbayarKeyPressed

    private void txbayarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txbayarKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode()== KeyEvent.VK_ENTER){
            int total = Integer.parseInt(txtTotal.getText().replace("Rp.", "").replaceAll("\\s+", "").replace(",-", ""));
            int pay = Integer.parseInt(txbayar.getText());
            if (total > pay){
                JOptionPane.showMessageDialog(null, "Uang yang dibayarkan kurang");
            }else {
                int kembalian = pay - total;
                txkembali.setText(String.valueOf(kembalian));}
        }
    }//GEN-LAST:event_txbayarKeyReleased

    private void txtnotransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnotransaksiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnotransaksiActionPerformed

    private void DateTimePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_DateTimePropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_DateTimePropertyChange

    private void cbKodePartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbKodePartActionPerformed
        // TODO add your handling code here:
        String selectedBarang = (String) cbKodePart.getSelectedItem();

        // Hindari proses jika pilihan default atau null
        if (selectedBarang == null || selectedBarang.equals("Pilih Barang")) {
            txtNamaPart.setText("");
            stok.setText("");
            return;
        }

        try {
            // Pisahkan kode barang
            String kodeBarang = selectedBarang.split(" - ")[0];

            // Query untuk mendapatkan detail barang
            String sql = "SELECT nama_barang, stok FROM data_barang WHERE kode_barang = ?";
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, kodeBarang);
                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        // Set nama barang dan stok
                        txtNamaPart.setText(rs.getString("nama_barang"));
                        stok.setText(rs.getString("stok"));

                        // Debugging: Cetak detail barang yang dipilih
                        System.out.println("Barang terpilih: " + rs.getString("nama_barang"));
                        System.out.println("Stok: " + rs.getString("stok"));
                    } else {
                        // Tampilkan pesan jika barang tidak ditemukan
                        JOptionPane.showMessageDialog(null,
                            "Barang tidak ditemukan.",
                            "Peringatan",
                            JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saat memilih barang:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Gagal memuat detail barang: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cbKodePartActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DateTime;
    private javax.swing.JButton btnBersih;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnbayar;
    private javax.swing.JButton btndelete;
    private javax.swing.JComboBox<String> cbKodePart;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField stok;
    private javax.swing.JTable tabelBarangMasuk;
    private javax.swing.JTextField txbayar;
    private javax.swing.JTextField txkembali;
    private javax.swing.JTextField txtJumlahBarang;
    private javax.swing.JTextField txtNamaPart;
    private javax.swing.JLabel txtTotal;
    private javax.swing.JTextField txtnotransaksi;
    // End of variables declaration//GEN-END:variables
}
