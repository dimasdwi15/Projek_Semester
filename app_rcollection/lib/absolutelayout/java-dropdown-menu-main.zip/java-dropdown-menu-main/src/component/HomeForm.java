package component;

import java.awt.Color;
import java.beans.PropertyChangeEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import raven.chart.geo.utils.GeoData;

public class HomeForm extends javax.swing.JPanel {

    public HomeForm() {
        initComponents();
        tanggal();
        barang();

        itemservis();
        
    }
     public void tanggal() {
        Date dt = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        DateTime.setText(sdf.format(dt));
    }
    public void barang(){
        try{
            String sql = "SELECT count(detail_brgkeluar.kode_barang) as Jumlah FROM detail_brgkeluar Join brg_keluar on brg_keluar.no_transaksi=detail_brgkeluar.no_transaksi WHERE brg_keluar.tanggal BETWEEN \n" +
"    CAST(\n" +
"        CONCAT(CURDATE()) AS DATETIME\n" +
"    )\n" +
"    AND NOW()\n" +
" \n" +
"ORDER BY\n" +
" detail_brgkeluar.no_transaksi ASC; ";
            java.sql.Connection conn = koneksi.getKoneksi();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            java.sql.ResultSet res = pst.executeQuery(sql);
            while(res.next()){
                itembrg.setText(res.getString("Jumlah"));
            }

        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }
    
    
    public void itemservis(){
        try{
            String sql = "SELECT count(detail_brgmasuk.no_faktur) as Jumlah FROM detail_brgmasuk Join brg_masuk on brg_masuk.no_faktur=detail_brgmasuk.no_faktur WHERE brg_masuk.tanggal BETWEEN \n" +
"    CAST(\n" +
"        CONCAT(CURDATE()) AS DATETIME\n" +
"    )\n" +
"    AND NOW()\n" +
" \n" +
"ORDER BY\n" +
" detail_brgmasuk.no_faktur ASC; ";
            java.sql.Connection conn = koneksi.getKoneksi();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            
            java.sql.ResultSet res = pst.executeQuery(sql);
            
            while(res.next()){
                servisitem.setText(res.getString("Jumlah"));
            }

        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }
    // Panggil metode barangTerjual() pada saat peristiwa tertentu, misalnya saat mengklik tombol atau mengubah tanggal
// ...

// Contoh saat mengklik tombol


// Contoh saat mengubah tanggal pada komponen tgl1 (misalnya JDateChooser)

    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        servisitem1 = new javax.swing.JLabel();
        itembrg1 = new javax.swing.JLabel();
        itembrg = new javax.swing.JLabel();
        servisitem = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        DateTime = new javax.swing.JLabel();

        setBackground(new java.awt.Color(245, 245, 245));
        setPreferredSize(new java.awt.Dimension(924, 576));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        servisitem1.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        servisitem1.setForeground(new java.awt.Color(244, 244, 244));
        servisitem1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        servisitem1.setText("Pembelian");
        add(servisitem1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 330, 190, -1));

        itembrg1.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        itembrg1.setForeground(new java.awt.Color(244, 244, 244));
        itembrg1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        itembrg1.setText("Penjualan");
        add(itembrg1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 330, 180, -1));

        itembrg.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        itembrg.setForeground(new java.awt.Color(244, 244, 244));
        itembrg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        itembrg.setText("jLabel1");
        add(itembrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 420, 90, -1));

        servisitem.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        servisitem.setForeground(new java.awt.Color(244, 244, 244));
        servisitem.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        servisitem.setText("jLabel1");
        add(servisitem, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 420, 70, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/menu/dashbord.png"))); // NOI18N
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 930, 585));

        DateTime.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        DateTime.setForeground(new java.awt.Color(255, 255, 255));
        DateTime.setText("jLabel10");
        add(DateTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 250, -1));
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DateTime;
    private javax.swing.JLabel itembrg;
    private javax.swing.JLabel itembrg1;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel servisitem;
    private javax.swing.JLabel servisitem1;
    // End of variables declaration//GEN-END:variables
}
