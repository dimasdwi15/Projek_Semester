/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;

import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class Barang extends javax.swing.JPanel {
    Connection conn;
    Statement st;
    ResultSet rs;
    /**
     * Creates new form Barang
     */
    public Connection setKoneksi(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rcollection","root","");
            st=conn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Koneksi Gagal :" +e);
        }
       return conn; 
    }

    public Barang() {
        initComponents();
        
        siapIsi(false);
        tombolNormal();
        tampil();
        otomatis();
        stockTF.setText("0");
    }
private void simpanData() {
    String kodeBarang = kodeTF.getText().trim();
    String namaBarang = namaTF.getText().trim();
    String stok = stockTF.getText().trim();
    String hargaBeli = beliTF.getText().trim();
    String hargaJual = jualTF.getText().trim();

    // Validasi input
    if (kodeBarang.isEmpty() || namaBarang.isEmpty() || stok.isEmpty() || hargaBeli.isEmpty() || hargaJual.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Lengkapi semua inputan data!", "Warning", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try (Connection conn = setKoneksi()) {
        // Periksa apakah koneksi berhasil
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Query untuk menyimpan data
        String sql = "INSERT INTO data_barang (kode_barang, nama_barang, stok, harga_beli, harga_jual) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kodeBarang);
            ps.setString(2, namaBarang);
            ps.setInt(3, Integer.parseInt(stok));
            ps.setDouble(4, Double.parseDouble(hargaBeli));
            ps.setDouble(5, Double.parseDouble(hargaJual));

            // Eksekusi query
            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil disimpan!", "Success", JOptionPane.INFORMATION_MESSAGE);
                bersih(); // Bersihkan form setelah berhasil menyimpan
                tampil(); // Refresh tabel setelah penyimpanan
            } else {
                JOptionPane.showMessageDialog(this, "Data gagal disimpan. Tidak ada baris yang ditambahkan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Input tidak valid! Pastikan stok, harga beli, dan harga jual berupa angka.", "Warning", JOptionPane.WARNING_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void bersih(){
        kodeTF.setText("");
        namaTF.setText("");
        beliTF.setText("");
        jualTF.setText("");
        stockTF.setText("0");
    }

    private void siapIsi(boolean a){
        kodeTF.setEnabled(a);
        namaTF.setEnabled(a);
        beliTF.setEnabled(a);
        jualTF.setEnabled(a);
        stockTF.setEnabled(a);
    }
    
    private void tombolNormal(){
        tambahBT.setEnabled(true);
        simpanBT.setEnabled(false);
        hapusBT.setEnabled(false);
        editBT.setEnabled(false);
        keluarBT.setEnabled(true);
        cariBT.setEnabled(true);
    }
    
    private void otomatis(){
        try {
            setKoneksi();
            String sql="select right (kode_barang,2)+1 from data_barang";
            ResultSet rs=st.executeQuery(sql);
            
           
           
            if(rs.next()){
                rs.last();
                String no=rs.getString(1);
                while (no.length()<3){
                    no="0"+no;
                    kodeTF.setText("B"+no);}
                }
            else
            {
                kodeTF.setText("B001"); 
            }
            } catch (Exception e) 
            {
        }
    }
    
    private void simpan(){
        try{
            setKoneksi();
            String sql="insert into data_barang values('"+ kodeTF.getText() +"','" + namaTF.getText() 
                    + "','" + stockTF.getText()+ "','" + beliTF.getText() + "','" + jualTF.getText() +"')";
            st.executeUpdate(sql); 
            JOptionPane.showMessageDialog(null,"Simpan data berhasil");
            }
            catch (Exception e) {
        }
        tampil();
    }
    
    private void perbarui(){
        try{
            setKoneksi();
            String sql="update data_barang set nama_barang='"+namaTF.getText()+"',harga_beli='"+beliTF.getText()+
                    "',harga_jual='"+jualTF.getText()+"' where kode_barang='"+kodeTF.getText()+"'";
            st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"Edit data berhasil","R.COLLECTION",JOptionPane.INFORMATION_MESSAGE);
        } 
        catch(Exception e){
        }
        tampil();
    }
    
    public void tampil(){
        Object header[]={"Kode Barang","Nama Barang","Stok","Harga Beli","Harga Jual"};
        DefaultTableModel data=new DefaultTableModel(null,header);
        jTable1.setModel(data);
        setKoneksi();
        String sql="select*from data_barang";
        try {
            ResultSet rs=st.executeQuery(sql);
            while (rs.next())
            {
                String kolom1=rs.getString(1);
                String kolom2=rs.getString(2);
                String kolom3=rs.getString(3);
                String kolom4=rs.getString(4);
                String kolom5=rs.getString(5);
                String kolom[]={kolom1,kolom2,kolom3,kolom4,kolom5};
                data.addRow(kolom);
            }
        } catch (Exception e) {
        }
    }
    



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kodeTF = new javax.swing.JTextField();
        namaTF = new javax.swing.JTextField();
        stockTF = new javax.swing.JTextField();
        jualTF = new javax.swing.JTextField();
        cariTF = new javax.swing.JTextField();
        simpanBT = new javax.swing.JButton();
        editBT = new javax.swing.JButton();
        tambahBT = new javax.swing.JButton();
        hapusBT = new javax.swing.JButton();
        cariBT = new javax.swing.JButton();
        beliTF = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        keluarBT = new javax.swing.JTextField();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kodeTF.setBorder(null);
        add(kodeTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 150, 30));

        namaTF.setBorder(null);
        add(namaTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 120, 150, 30));

        stockTF.setBorder(null);
        add(stockTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 170, 150, 30));

        jualTF.setBorder(null);
        jualTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jualTFActionPerformed(evt);
            }
        });
        add(jualTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 150, 30));

        cariTF.setBorder(null);
        cariTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariTFActionPerformed(evt);
            }
        });
        cariTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cariTFKeyReleased(evt);
            }
        });
        add(cariTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 320, 260, 40));

        simpanBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Disk.png"))); // NOI18N
        simpanBT.setContentAreaFilled(false);
        simpanBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanBTActionPerformed(evt);
            }
        });
        add(simpanBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 230, 60, -1));

        editBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Pen.png"))); // NOI18N
        editBT.setContentAreaFilled(false);
        editBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBTActionPerformed(evt);
            }
        });
        add(editBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 230, 60, -1));

        tambahBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Salib.png"))); // NOI18N
        tambahBT.setContentAreaFilled(false);
        tambahBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahBTActionPerformed(evt);
            }
        });
        add(tambahBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 230, 60, -1));

        hapusBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/sampah.png"))); // NOI18N
        hapusBT.setContentAreaFilled(false);
        hapusBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusBTActionPerformed(evt);
            }
        });
        add(hapusBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 230, 60, -1));

        cariBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/kaca pembesar.png"))); // NOI18N
        cariBT.setContentAreaFilled(false);
        cariBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariBTActionPerformed(evt);
            }
        });
        add(cariBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 310, 70, 60));

        beliTF.setBorder(null);
        add(beliTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 150, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 870, 180));

        jPanel1.setBackground(new java.awt.Color(118, 98, 18));
        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 10, 130, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/menu/data barang.png"))); // NOI18N
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        keluarBT.setText("jTextField1");
        keluarBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keluarBTActionPerformed(evt);
            }
        });
        add(keluarBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 22, 130, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void jualTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jualTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jualTFActionPerformed

    private void jTextFkodeTFPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void keluarBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keluarBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_keluarBTActionPerformed

    private void simpanBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanBTActionPerformed
        simpanData();
    }//GEN-LAST:event_simpanBTActionPerformed

    private void tambahBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahBTActionPerformed
       if (tambahBT.getText().equalsIgnoreCase("Tambah")) {
        siapIsi(true); // Aktifkan input
        bersih(); // Bersihkan field
        otomatis(); // Buat kode barang otomatis
        tambahBT.setText("Batal"); // Ubah tombol ke "Batal"
        simpanBT.setEnabled(true); // Aktifkan tombol simpan
        editBT.setEnabled(false);
        hapusBT.setEnabled(false);
    } else { // Ketika tombol bertuliskan "Batal"
        bersih(); // Bersihkan input
        siapIsi(false); // Nonaktifkan input
        tambahBT.setText("Tambah"); // Ubah tombol kembali ke "Tambah"
        tombolNormal(); // Kembalikan ke keadaan tombol awal
    }
    }//GEN-LAST:event_tambahBTActionPerformed

    private void cariBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariBTActionPerformed
        // TODO add your handling code here:
        Object header[]={"Kode Barang","Nama Barang","Stok","Harga Beli","Harga Jual"};
        DefaultTableModel data=new DefaultTableModel(null,header);
        jTable1.setModel(data);
        setKoneksi();
        String sql="Select * from data_barang where kode_barang like '%" + cariTF.getText() + "%'" + "or nama_barang like '%" + cariTF.getText()+ "%'";
        try {
            ResultSet rs=st.executeQuery(sql);
            while (rs.next())
            {
                String kolom1=rs.getString(1);
                String kolom2=rs.getString(2);
                String kolom3=rs.getString(3);
                String kolom4=rs.getString(4);
                String kolom5=rs.getString(5);
                 
                
                String kolom[]={kolom1,kolom2,kolom3,kolom4,kolom5,};
                data.addRow(kolom);
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cariBTActionPerformed

    private void editBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBTActionPerformed
        
        String sql = null;      
        String kodeBarang = kodeTF.getText();
try {
    koneksi.getKoneksi(); 

    
    if (JOptionPane.showConfirmDialog(null, "Apakah Anda ingin mengubah data barang ini?", "Warning", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
        
        
        sql = "UPDATE data_barang SET " +
              "nama_barang = '" + namaTF.getText() + "', " +
              "stok = " + Integer.parseInt(stockTF.getText()) + ", " +
              "harga_beli = " + Double.parseDouble(beliTF.getText()) + ", " +
              "harga_jual = " + Double.parseDouble(jualTF.getText()) + " " +
              "WHERE kode_barang = '" + kodeBarang + "'";

        Statement state = (Statement) koneksi.getKoneksi().createStatement();
        int hasil = state.executeUpdate(sql);

        if (hasil == 1) {
            JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
        }

        tampil();

        kodeTF.setText("");
        namaTF.setText("");
        stockTF.setText("");
        beliTF.setText("");
        jualTF.setText("");

        kodeTF.setEnabled(false);
        namaTF.setEnabled(false);
        stockTF.setEnabled(false);
        beliTF.setEnabled(false);
        jualTF.setEnabled(false);

    }
} catch (Exception ex) {
    JOptionPane.showMessageDialog(null, ex.getMessage());
}

    }//GEN-LAST:event_editBTActionPerformed

    private void hapusBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusBTActionPerformed
  // Ambil kode barang yang ingin dihapus dari text field
    String kodeBarang = kodeTF.getText();

    if (kodeBarang.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!", "Warning", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Konfirmasi penghapusan
    int pesan = JOptionPane.showConfirmDialog(this, "Yakin data akan dihapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

    if (pesan == JOptionPane.YES_OPTION) {
        // Menggunakan try-with-resources untuk mendapatkan koneksi
        try (Connection conn = setKoneksi()) {
            // Mulai transaksi
            conn.setAutoCommit(false);

            // Hapus data dari detail_brgmasuk terlebih dahulu
            String sql1 = "DELETE FROM detail_brgmasuk WHERE kode_barang = ?";
            try (PreparedStatement stmt1 = conn.prepareStatement(sql1)) {
                stmt1.setString(1, kodeBarang);
                stmt1.executeUpdate();
            }

            // Hapus data dari detail_brgkeluar
            String sql2 = "DELETE FROM detail_brgkeluar WHERE kode_barang = ?";
            try (PreparedStatement stmt2 = conn.prepareStatement(sql2)) {
                stmt2.setString(1, kodeBarang);
                stmt2.executeUpdate();
            }

            // Hapus data dari data_barang
            String sql3 = "DELETE FROM data_barang WHERE kode_barang = ?";
            try (PreparedStatement stmt3 = conn.prepareStatement(sql3)) {
                stmt3.setString(1, kodeBarang);
                stmt3.executeUpdate();
            }

            // Commit transaksi jika berhasil
            conn.commit();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");

        } catch (SQLException e) {
            // Jika terjadi error, rollback transaksi
            try (Connection conn = setKoneksi()) {
                conn.rollback(); // rollback untuk koneksi yang sudah ada
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Hapus data gagal: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Penghapusan dibatalkan", "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    }//GEN-LAST:event_hapusBTActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int baris = jTable1.getSelectedRow();
        kodeTF.setText(jTable1.getModel().getValueAt(baris, 0).toString());
        namaTF.setText(jTable1.getModel().getValueAt(baris, 1).toString());
        beliTF.setText(jTable1.getModel().getValueAt(baris, 3).toString());
        jualTF.setText(jTable1.getModel().getValueAt(baris, 4).toString());
        stockTF.setText(jTable1.getModel().getValueAt(baris, 2).toString());
        hapusBT.setEnabled(true);
        editBT.setEnabled(true);
        kodeTF.setEnabled(true);
        namaTF.setEnabled(true);
        beliTF.setEnabled(true);
        jualTF.setEnabled(true);
        stockTF.setEnabled(true);
    }//GEN-LAST:event_jTable1MouseClicked

    private void cariTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariTFActionPerformed
        // TODO add your handling code here:
        Object header[]={"Kode Barang","Nama Barang","Stok","Harga Beli","Harga Jual"};
        DefaultTableModel data=new DefaultTableModel(null,header);
        jTable1.setModel(data);
        setKoneksi();
        String sql="Select * from data_barang where kode_barang like '%" + cariTF.getText() + "%'" + "or nama_barang like '%" + cariTF.getText()+ "%'";
        try {
            ResultSet rs=st.executeQuery(sql);
            while (rs.next())
            {
                String kolom1=rs.getString(1);
                String kolom2=rs.getString(2);
                String kolom3=rs.getString(3);
                String kolom4=rs.getString(4);
                String kolom5=rs.getString(5);
                 
                
                String kolom[]={kolom1,kolom2,kolom3,kolom4,kolom5,};
                data.addRow(kolom);
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cariTFActionPerformed

    private void cariTFKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cariTFKeyReleased
        // TODO add your handling code here:
        Object header[]={"Kode Barang","Nama Barang","Stok","Harga Beli","Harga Jual"};
        DefaultTableModel data=new DefaultTableModel(null,header);
        jTable1.setModel(data);
        setKoneksi();
        String sql="Select * from data_barang where kode_barang like '%" + cariTF.getText() + "%'" + "or nama_barang like '%" + cariTF.getText()+ "%'";
        try {
            ResultSet rs=st.executeQuery(sql);
            while (rs.next())
            {
                String kolom1=rs.getString(1);
                String kolom2=rs.getString(2);
                String kolom3=rs.getString(3);
                String kolom4=rs.getString(4);
                String kolom5=rs.getString(5);
                 
                
                String kolom[]={kolom1,kolom2,kolom3,kolom4,kolom5,};
                data.addRow(kolom);
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cariTFKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField beliTF;
    private javax.swing.JButton cariBT;
    private javax.swing.JTextField cariTF;
    private javax.swing.JButton editBT;
    private javax.swing.JButton hapusBT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jualTF;
    private javax.swing.JTextField keluarBT;
    private javax.swing.JTextField kodeTF;
    private javax.swing.JTextField namaTF;
    private javax.swing.JButton simpanBT;
    private javax.swing.JTextField stockTF;
    private javax.swing.JButton tambahBT;
    // End of variables declaration//GEN-END:variables
}
