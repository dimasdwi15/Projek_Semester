/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class sok implements KeyListener {
    private JFrame loginFrame;
    private JTextField rfidField;

    public final Connection conn =  koneksi.getKoneksi();

    public sok() {
        loginFrame = new JFrame("Login Form");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel loginPanel = new JPanel(new GridLayout(2, 2));

        JLabel rfidLabel = new JLabel("RFID:");
        rfidField = new JTextField(10);

        rfidField.addKeyListener(this); // Add key listener to the RFID field

        loginPanel.add(rfidLabel);
        loginPanel.add(rfidField);

        loginFrame.add(loginPanel);
        loginFrame.pack();
        loginFrame.setVisible(true);
    }

    private void authenticate(String rfid) {
        try {
            Connection connection = conn;
            String query = "SELECT * FROM tb_user WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, rfid);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String role = resultSet.getString("level");
                openDashboard(role);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid RFID", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void openDashboard(String role) {
        loginFrame.dispose();
        // Open the dashboard based on the role
        JOptionPane.showMessageDialog(null, "Logged in as " + role, "Login Successful", JOptionPane.INFORMATION_MESSAGE);
        // ...
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // Not used
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // When a key is released in the RFID field, authenticate the RFID value
        String rfid = rfidField.getText();
        authenticate(rfid);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new sok();
            }
        });
    }
}










    
        
