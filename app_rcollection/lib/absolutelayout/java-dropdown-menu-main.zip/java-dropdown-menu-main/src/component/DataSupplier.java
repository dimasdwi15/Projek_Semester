/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author ASUS
 */
public class DataSupplier extends javax.swing.JPanel {
    Connection conn;
    Statement st;
    ResultSet rs;
    /**
     * Creates new form DataSupplier
     */
    public DataSupplier() {
        initComponents();
        tampil();
        otomatis();
        siapIsi(false);
        tombolNormal();
    }
      
     private void bersih(){
        kodeTF.setText("");
        nama1TF.setText("");
        tlpTF.setText("");
        alamatTF.setText("");
    }

    private void siapIsi(boolean a){
        kodeTF.setEnabled(a);
        nama1TF.setEnabled(a);
        tlpTF.setEnabled(a);
        alamatTF.setEnabled(a);
    }
    
    private void tombolNormal(){
        tambahBT.setEnabled(true);
        simpanBT.setEnabled(false);
        hapusBT.setEnabled(false);
        editBT.setEnabled(false);
        keluarBT.setEnabled(true);
        cariBT.setEnabled(true);
    }
    
    public void tampil(){
        try {
        setKoneksi();
        String sql = "SELECT * FROM tb_supplier";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        // Clear data tabel sebelum memuat ulang
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        // Tambahkan data ke tabel
        while (rs.next()) {
            Object[] row = {
                rs.getString("kode_supplier"),
                rs.getString("nama_supplier"),
                rs.getString("tlp"),
                rs.getString("alamat"),
                rs.getDate("tanggal") // jika ada kolom tanggal
            };
            model.addRow(row);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Gagal memuat data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }
    
    public void simpan() {
    try {
        setKoneksi(); // Pastikan koneksi database berhasil
       String sql = "INSERT INTO tb_supplier (kode_supplier, nama_supplier, tlp, alamat, tanggal) VALUES (?, ?, ?, ?, ?)";
PreparedStatement pst = conn.prepareStatement(sql);
pst.setString(1, kodeTF.getText());
pst.setString(2, nama1TF.getText());
pst.setString(3, tlpTF.getText());
pst.setString(4, alamatTF.getText());
pst.setDate(5, new java.sql.Date(System.currentTimeMillis())); // Menggunakan tanggal saat ini
pst.executeUpdate();

    } catch (SQLException e) {
        throw new RuntimeException("Error saat menyimpan: " + e.getMessage());
    }
}

    
    public void perbarui() {
    try {
        setKoneksi(); // Pastikan koneksi database berhasil
       String sql = "UPDATE tb_supplier SET nama_supplier = ?, tlp = ?, alamat = ?, tanggal = ? WHERE kode_supplier = ?";
PreparedStatement pst = conn.prepareStatement(sql);
pst.setString(1, nama1TF.getText());
pst.setString(2, tlpTF.getText());
pst.setString(3, alamatTF.getText());
pst.setDate(4, new java.sql.Date(System.currentTimeMillis())); // Menggunakan tanggal saat ini
pst.setString(5, kodeTF.getText());
pst.executeUpdate();

    } catch (SQLException e) {
        throw new RuntimeException("Error saat memperbarui: " + e.getMessage());
    }
}

    
    private void otomatis(){
        try {
            setKoneksi();
            String sql="select right (kode_supplier,2)+1 from tb_supplier";
            ResultSet rs=st.executeQuery(sql);
            
            if(rs.next()){
                rs.last();
                String no=rs.getString(1);
                while (no.length()<3){
                    no="0"+no;
                    kodeTF.setText("S"+no);}
                }
            else
            {
                kodeTF.setText("S001"); 
            }
            } catch (Exception e) 
            {
        }
    }
    
    private void hapus(){
        try{
            setKoneksi();
            String sql="delete from tb_supplier where kode_supplier='"+ kodeTF.getText() +"'";
            st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Hapus data sukses");
            }
            catch (Exception e) {
            }
        tampil();
    }
    public Connection setKoneksi(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rcollection","root","");
            st=conn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Koneksi Gagal :" +e);
        }
       return conn; 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cariTF = new javax.swing.JTextField();
        kodeTF = new javax.swing.JTextField();
        nama1TF = new javax.swing.JTextField();
        tlpTF = new javax.swing.JTextField();
        alamatTF = new javax.swing.JTextField();
        tambahBT = new javax.swing.JButton();
        editBT = new javax.swing.JButton();
        hapusBT = new javax.swing.JButton();
        simpanBT = new javax.swing.JButton();
        cariBT = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        keluarBT = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cariTF.setBorder(null);
        cariTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariTFActionPerformed(evt);
            }
        });
        add(cariTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, 270, 40));

        kodeTF.setBorder(null);
        kodeTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kodeTFActionPerformed(evt);
            }
        });
        add(kodeTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 170, 30));

        nama1TF.setBorder(null);
        add(nama1TF, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 190, 170, 30));

        tlpTF.setBorder(null);
        add(tlpTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 240, 170, 30));

        alamatTF.setBorder(null);
        alamatTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alamatTFActionPerformed(evt);
            }
        });
        add(alamatTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 150, 180, 30));

        tambahBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Salib.png"))); // NOI18N
        tambahBT.setContentAreaFilled(false);
        tambahBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahBTActionPerformed(evt);
            }
        });
        add(tambahBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 240, 60, 60));

        editBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Pen.png"))); // NOI18N
        editBT.setContentAreaFilled(false);
        editBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBTActionPerformed(evt);
            }
        });
        add(editBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 240, 60, 60));

        hapusBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/sampah.png"))); // NOI18N
        hapusBT.setContentAreaFilled(false);
        hapusBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusBTActionPerformed(evt);
            }
        });
        add(hapusBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 240, 60, 60));

        simpanBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Disk.png"))); // NOI18N
        simpanBT.setContentAreaFilled(false);
        simpanBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanBTActionPerformed(evt);
            }
        });
        add(simpanBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 240, 60, 60));

        cariBT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/kaca pembesar.png"))); // NOI18N
        cariBT.setContentAreaFilled(false);
        cariBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariBTActionPerformed(evt);
            }
        });
        add(cariBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 320, 70, 60));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Supplier", "Nama Supplier", "No Telp", "Alamat"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 860, 170));

        jPanel1.setBackground(new java.awt.Color(118, 98, 18));
        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, 160, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/menu/Data Supplier.png"))); // NOI18N
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 920, 600));

        keluarBT.setText("jLabel2");
        add(keluarBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(761, 16, 150, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void cariBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariBTActionPerformed
        // TODO add your handling code here:
        Object header[]={"KodeSupplier","Nama","NoTelepon","Alamat"};
        DefaultTableModel data=new DefaultTableModel(null,header);
        jTable1.setModel(data);
        setKoneksi();
        String sql="Select * from tb_supplier where kode_supplier like '%" + cariTF.getText() + "%'" + "or nama_supplier like '%" + cariTF.getText()+ "%'";
        try {
            ResultSet rs=st.executeQuery(sql);
            while (rs.next())
            {
                String kolom1=rs.getString(1);
                String kolom2=rs.getString(2);
                String kolom3=rs.getString(3);
                String kolom4=rs.getString(4);
                
                
                String kolom[]={kolom1,kolom2,kolom3,kolom4};
                data.addRow(kolom);
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cariBTActionPerformed

    private void kodeTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kodeTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_kodeTFActionPerformed

    private void alamatTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alamatTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alamatTFActionPerformed

    private void cariTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cariTFActionPerformed

    private void tambahBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahBTActionPerformed
        // TODO add your handling code here:
        if(tambahBT.getText().equalsIgnoreCase("tambah")){
            tambahBT.setText("Batal");
            bersih();
            siapIsi(true);
            otomatis();
            nama1TF.requestFocus();
            kodeTF.setEnabled(false);
            tambahBT.setEnabled(true);
            simpanBT.setEnabled(true);
            hapusBT.setEnabled(false);
            editBT.setEnabled(false);
            keluarBT.setEnabled(false);
            cariBT.setEnabled(true);
        } else{
            tambahBT.setText("Tambah");
            bersih();
            siapIsi(false);
            tombolNormal();
        }
    }//GEN-LAST:event_tambahBTActionPerformed

    private void simpanBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanBTActionPerformed
       // Pastikan semua input sudah lengkap
    if (nama1TF.getText().isEmpty() || tlpTF.getText().isEmpty() || alamatTF.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Lengkapi inputan data", "R.COLLECTION", JOptionPane.INFORMATION_MESSAGE);
        return; // Menghentikan eksekusi jika ada field yang kosong
    }

    try {
        if (tambahBT.getText().equalsIgnoreCase("Batal")) {
            // Logika untuk menambahkan data
            simpan(); // Panggil method untuk menyimpan data
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan.", "R.COLLECTION", JOptionPane.INFORMATION_MESSAGE);
        } else if (editBT.getText().equalsIgnoreCase("Batal")) {
            // Logika untuk memperbarui data
            perbarui(); // Panggil method untuk memperbarui data
            JOptionPane.showMessageDialog(this, "Data berhasil diperbarui.", "R.COLLECTION", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Operasi tidak valid.", "R.COLLECTION", JOptionPane.WARNING_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "R.COLLECTION", JOptionPane.ERROR_MESSAGE);
    }

    // Reset form setelah simpan atau perbarui
    bersih();
    siapIsi(false);
    tambahBT.setText("Tambah");
    editBT.setText("Edit");
    tombolNormal();
    tampil();

    }//GEN-LAST:event_simpanBTActionPerformed

    private void editBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBTActionPerformed
        // TODO add your handling code here:
        if(editBT.getText().equalsIgnoreCase("edit")){
            editBT.setText("Batal");
            siapIsi(true);
            kodeTF.setEnabled(false);
            nama1TF.requestFocus();
            tambahBT.setEnabled(false);
            simpanBT.setEnabled(true);
            hapusBT.setEnabled(false);
            editBT.setEnabled(true);
            keluarBT.setEnabled(false);
            cariBT.setEnabled(false);
        } else{
            editBT.setText("Edit");
            bersih();
            siapIsi(false);
            tombolNormal();
        }
    }//GEN-LAST:event_editBTActionPerformed

    private void hapusBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusBTActionPerformed
        // TODO add your handling code here:
        int pesan=JOptionPane.showConfirmDialog(null, "Yakin data akan dihapus ?","Konfirmasi",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(pesan==JOptionPane.YES_OPTION){
            if(pesan==JOptionPane.YES_OPTION){
                hapus();
                bersih();
                siapIsi(false);
                tombolNormal();
            } else{
                JOptionPane.showMessageDialog(null, "Hapus data gagal");
            }
            tampil();
        }
    }//GEN-LAST:event_hapusBTActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int baris = jTable1.getSelectedRow();
        kodeTF.setText(jTable1.getModel().getValueAt(baris, 0).toString());
        nama1TF.setText(jTable1.getModel().getValueAt(baris, 1).toString());
        tlpTF.setText(jTable1.getModel().getValueAt(baris, 2).toString());
        alamatTF.setText(jTable1.getModel().getValueAt(baris, 3).toString());
        hapusBT.setEnabled(true);
        editBT.setEnabled(true);
    }//GEN-LAST:event_jTable1MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alamatTF;
    private javax.swing.JButton cariBT;
    private javax.swing.JTextField cariTF;
    private javax.swing.JButton editBT;
    private javax.swing.JButton hapusBT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel keluarBT;
    private javax.swing.JTextField kodeTF;
    private javax.swing.JTextField nama1TF;
    private javax.swing.JButton simpanBT;
    private javax.swing.JButton tambahBT;
    private javax.swing.JTextField tlpTF;
    // End of variables declaration//GEN-END:variables
}
