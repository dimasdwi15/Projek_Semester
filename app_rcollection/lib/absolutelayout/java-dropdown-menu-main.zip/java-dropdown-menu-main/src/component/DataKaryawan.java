/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class DataKaryawan extends javax.swing.JPanel {
    Connection con = null;
    PreparedStatement pst = null;
    Statement st =null;
    ResultSet rs = null;
    /**
     * Creates new form DataKaryawan
     */
    public DataKaryawan() {
        initComponents();
        initComponents();
        datatable();
        otomatis();
        btnedit.setEnabled(false);
       btnhapus.setEnabled(false);
       btnsave.setEnabled(false);
       txtidkaryawan.setEnabled(false);
       txtnamakaryawan.setEnabled(false);
       cjk.setEnabled(false);
       txtalamat.setEnabled(false);
       txtusername.setEnabled(false);
       txtpassword.setEnabled(false);
       chak.setEnabled(false);
    }
     public void hapus() {
        try {
            String sql ="delete from tb_user where nama='"+txtnamakaryawan.getText()+"'" ;
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rcollection","root","");
            
            java.sql.PreparedStatement pst=con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this,"terhapus");
            datatable();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    private void autoIdBM() {
        try {
            Connection con =  koneksi.getKoneksi();
            java.sql.Statement stat = con.createStatement();
            String sql = "select max(right (id,6)) as no from tb_user";
            ResultSet res = stat.executeQuery(sql);
            while (res.next()) {
                if (res.first() == false) {
                    txtidkaryawan.setText("A0001");
                } else {
                    res.last();
                    int aut_id = res.getInt(1) + 1;
                    String no = String.valueOf(aut_id);
                    int no_jual = no.length();
                    // mengatur jumlah 0
                    for (int j = 0; j < 3 - no_jual; j++) {
                        no = "0" + no;
                    }
                    txtidkaryawan.setText("A" + no);
                }
            }
            res.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalahan");
        }
    } 
    public Connection setKoneksi(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/rcollection","root","");
            st=con.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Koneksi Gagal :" +e);
        }
       return con; 
    }
    private void otomatis(){
        try {
            setKoneksi();
            String sql="select right (id,2)+1 from tb_user";
            ResultSet rs=st.executeQuery(sql);
            
           
           
            if(rs.next()){
                rs.last();
                String no=rs.getString(1);
                while (no.length()<3){
                    no="0"+no;
                    txtidkaryawan.setText("A"+no);}
                }
            else
            {
                txtidkaryawan.setText("A001"); 
            }
            } catch (Exception e) 
            {
        }
    }
    private void datatable(){
    
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("ID Pegawai");
    tbl.addColumn("Nama Pegawai");
    tbl.addColumn("Username");
    tbl.addColumn("Password");
    tbl.addColumn("Jenis Kelamin");
    tbl.addColumn("Alamat");
    tbl.addColumn("Jabatan");
    table.setModel(tbl);
    try{
       Statement statement = (Statement) koneksi.getKoneksi().createStatement();
        ResultSet res = statement.executeQuery("Select * from tb_user");
        while (res.next())
        {
         tbl.addRow(new Object[]{
           res.getString("id"),
           res.getString("Nama"),
           res.getString("username"),
           res.getString("password"),
           res.getString("cjenis"),
           res.getString("alamat"),
           res.getString("level")
         });
           table.setModel(tbl);
        } 
    }  catch (Exception ex) { 
        Component rootPane = null;
        JOptionPane.showMessageDialog(rootPane, "wkwkw"+ex.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        txtnamakaryawan = new javax.swing.JTextField();
        txtalamat = new javax.swing.JTextField();
        txtusername = new javax.swing.JTextField();
        txtpassword = new javax.swing.JTextField();
        txtidkaryawan = new javax.swing.JTextField();
        cjk = new javax.swing.JComboBox<>();
        chak = new javax.swing.JComboBox<>();
        btnsave = new javax.swing.JButton();
        btntambah = new javax.swing.JButton();
        btnedit = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();
        btncari = new javax.swing.JButton();
        txtcari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        keluarBT = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jButton5.setContentAreaFilled(false);

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtnamakaryawan.setBorder(null);
        add(txtnamakaryawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 150, 30));

        txtalamat.setBorder(null);
        txtalamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtalamatActionPerformed(evt);
            }
        });
        add(txtalamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 150, 30));

        txtusername.setBorder(null);
        add(txtusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 140, 140, 30));

        txtpassword.setBorder(null);
        add(txtpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 190, 140, 30));

        txtidkaryawan.setBorder(null);
        txtidkaryawan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidkaryawanActionPerformed(evt);
            }
        });
        add(txtidkaryawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 150, 30));

        cjk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "\"Pilih Jenis Kelamin\"", "L", "P" }));
        add(cjk, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 142, 140, 30));

        chak.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "\"Pilih Hak Akses\"", "Admin", "Kasir" }));
        add(chak, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 192, 140, 30));

        btnsave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Disk.png"))); // NOI18N
        btnsave.setContentAreaFilled(false);
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        add(btnsave, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 240, 60, 60));

        btntambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Salib.png"))); // NOI18N
        btntambah.setContentAreaFilled(false);
        btntambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntambahActionPerformed(evt);
            }
        });
        add(btntambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 240, 60, 60));

        btnedit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/Pen.png"))); // NOI18N
        btnedit.setContentAreaFilled(false);
        btnedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditActionPerformed(evt);
            }
        });
        add(btnedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 240, 60, 60));

        btnhapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/sampah.png"))); // NOI18N
        btnhapus.setContentAreaFilled(false);
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });
        add(btnhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 240, 60, 60));

        btncari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG/kaca pembesar.png"))); // NOI18N
        btncari.setContentAreaFilled(false);
        btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncariActionPerformed(evt);
            }
        });
        add(btncari, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 310, 70, 60));

        txtcari.setBorder(null);
        txtcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcariActionPerformed(evt);
            }
        });
        add(txtcari, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 320, 270, 40));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tableMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 870, 180));

        jPanel2.setBackground(new java.awt.Color(118, 98, 18));
        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 10, 150, 50));

        keluarBT.setText("jTextField1");
        keluarBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keluarBTActionPerformed(evt);
            }
        });
        add(keluarBT, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 22, 130, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/menu/karyawan.png"))); // NOI18N
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 930, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btncariActionPerformed

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        // TODO add your handling code here:
        String idkar = txtidkaryawan.getText();
        String nama = txtnamakaryawan.getText();
        String alamat = (String) txtalamat.getText();
        String username = txtusername.getText();
        String password = txtpassword.getText();
        try{
            int pil1=0;
        int pil2=0;
            koneksi.getKoneksi();
            String cjenis="";
            String cakses="";
            pil2 = cjk.getSelectedIndex();
            if (pil2==0) { cjenis="";}
            if (pil2==1) { cjenis="L";}
            if (pil2==2) { cjenis="P";}
            pil1 = chak.getSelectedIndex();
            if (pil1==0) { cakses="";}
            if (pil1==1) { cakses="Admin";}
            if (pil1==2) { cakses="Kasir";}
            Statement state = (Statement)koneksi.getKoneksi().createStatement();
            state.executeUpdate("insert into tb_user VALUES ('"+idkar+"','"+nama+"','"+username+"','"+password+"','"+cjenis+"','"+alamat+"','"+cakses+"');");
            state.close();
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
            autoIdBM();
        }catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Problem"+ex);
        }
        datatable();
        txtnamakaryawan.setEnabled(false);
       cjk.setEnabled(false);
       txtalamat.setEnabled(false);
       txtusername.setEnabled(false);
       txtpassword.setEnabled(false);
       chak.setEnabled(false);
        txtidkaryawan.getText();
        txtnamakaryawan.setText("");
        cjk.setSelectedIndex(0);
        txtalamat.setText("");
        txtusername.setText("");
        txtpassword.setText("");
        chak.setSelectedIndex(0);
    }//GEN-LAST:event_btnsaveActionPerformed

    private void btntambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntambahActionPerformed
        // TODO add your handling code here:
         btnedit.setEnabled(true);
        btnhapus.setEnabled(true);
        btnsave.setEnabled(true);
        txtidkaryawan.setEnabled(true);
        txtnamakaryawan.setEnabled(true);
        cjk.setEnabled(true);
        txtalamat.setEnabled(true);
        txtusername.setEnabled(true);
        txtpassword.setEnabled(true);
        chak.setEnabled(true);
        txtidkaryawan.setText("");
        txtnamakaryawan.setText("");
        cjk.setSelectedIndex(0);
        txtalamat.setText("");
        txtusername.setText("");
        txtpassword.setText("");
        chak.setSelectedIndex(0);
        otomatis();
    }//GEN-LAST:event_btntambahActionPerformed

    private void btneditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditActionPerformed
        // TODO add your handling code here:
        String sql = null;
     String idkar = txtidkaryawan.getText();
        try{
            int pil1=0;
        int pil2=0;
            koneksi.getKoneksi();
            String cjenis="";
            String cakses="";
            pil2 = cjk.getSelectedIndex();
            if (pil2==0) { cjenis="";}
            if (pil2==1) { cjenis="L";}
            if (pil2==2) { cjenis="P";}
            pil1 = chak.getSelectedIndex();
            if (pil1==0) { cakses="";}
            if (pil1==1) { cakses="Admin";}
            if (pil1==2) { cakses="Kasir";}
         if(JOptionPane.showConfirmDialog(null, "Apakah Anda Ingin Mengubah data ini?", "Warning",2)==JOptionPane.YES_OPTION)
             sql = "UPDATE tb_user SET nama='"+txtnamakaryawan.getText()+"', cjenis='"+cjenis+"', alamat='"+txtalamat.getText()+"',username='"+txtusername.getText()+"',password='"+txtpassword.getText()+"', level='"+cakses+"' where id='"+idkar+"'";
             Statement state = (Statement)koneksi.getKoneksi().createStatement();
             int kes = state.executeUpdate(sql);
             if(kes == 1){
                 JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
             }
             datatable();
            txtidkaryawan.setText("");
            txtnamakaryawan.setText("");
            cjk.setSelectedIndex(0);
            txtalamat.setText("");
            txtusername.setText("");
            txtpassword.setText("");
            chak.setSelectedIndex(0);
            txtidkaryawan.setEnabled(false);
            txtnamakaryawan.setEnabled(false);
            cjk.setEnabled(false);
            txtalamat.setEnabled(false);
            txtusername.setEnabled(false);
            txtpassword.setEnabled(false);
            chak.setEnabled(false);       
             
     }catch(Exception ex){
         JOptionPane.showMessageDialog(null, ex);
        }
    }//GEN-LAST:event_btneditActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
        // TODO add your handling code here:
        hapus();
        btnedit.setEnabled(false);
       btnhapus.setEnabled(false);
       btnsave.setEnabled(false);
       txtnamakaryawan.setEnabled(false);
       cjk.setEnabled(false);
       txtalamat.setEnabled(false);
       txtusername.setEnabled(false);
       txtpassword.setEnabled(false);
       chak.setEnabled(false);
       txtidkaryawan.setText("");
       txtnamakaryawan.setText("");
       cjk.setSelectedIndex(0);
       txtalamat.setText("");
       txtusername.setText("");
       txtpassword.setText("");
       chak.setSelectedIndex(0);
    }//GEN-LAST:event_btnhapusActionPerformed

    private void txtcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcariActionPerformed
        // TODO add your handling code here:
        try{
            Statement st = (Statement)koneksi.getKoneksi().createStatement();
            ResultSet res = st.executeQuery("select * from tb_user where "+"nama='"+txtcari.getText()+"'");
            DefaultTableModel tbl = new DefaultTableModel();
            tbl.addColumn("ID Pegawai");
            tbl.addColumn("Nama Pegawai");
            tbl.addColumn("Username");
            tbl.addColumn("Password");
            tbl.addColumn("Jenis Kelamin");
            tbl.addColumn("Alamat");
            tbl.addColumn("Hak");
            table.setModel(tbl);
        while (res.next())
        {
         tbl.addRow(new Object[]{
           res.getString("id"),
           res.getString("nama"),
           res.getString("username"),
           res.getString("alamat"),
           res.getString("cjenis"),
           res.getString("alamat"),
           res.getString("level")
         });
           table.setModel(tbl);
        } 
        }catch(Exception t){
            Logger.getLogger(DataKaryawan.class.getName()).log(Level.SEVERE, null, t);
            Component rootPane = null;
            JOptionPane.showMessageDialog(rootPane, "Data Tidak di Temukan!!!");
        }
        btnedit.setEnabled(true);
        txtcari.setText("");
    }//GEN-LAST:event_txtcariActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        int i = table.getSelectedRow();
        String id = table.getValueAt(i, 0).toString();
        String nama = table.getValueAt(i, 1).toString();
        String kelamin = table.getValueAt(i, 4).toString();
        String alamat = table.getValueAt(i, 5).toString();
        String username = table.getValueAt(i, 2).toString();
        String password = table.getValueAt(i, 3).toString();
        String hak = table.getValueAt(i, 6).toString();
        txtidkaryawan.setText(id);
        txtnamakaryawan.setText(nama);
        txtalamat.setText(alamat);
        txtusername.setText(username);
        txtpassword.setText(password);
        btnedit.setEnabled(true);
        btnhapus.setEnabled(true);
        txtnamakaryawan.setEnabled(true);
        cjk.setEnabled(true);
        txtalamat.setEnabled(true);
        txtusername.setEnabled(true);
        txtpassword.setEnabled(true);
        chak.setEnabled(true);
    }//GEN-LAST:event_tableMouseClicked

    private void tableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseReleased
        // TODO add your handling code here:
         int i = table.getSelectedRow();
        String id = table.getValueAt(i, 0).toString();
        String nama = table.getValueAt(i, 1).toString();
        String kelamin = table.getValueAt(i, 4).toString();
        String alamat = table.getValueAt(i, 5).toString();
        String username = table.getValueAt(i, 2).toString();
        String password = table.getValueAt(i, 3).toString();
        String hak = table.getValueAt(i, 6).toString();
        txtidkaryawan.setText(id);
        txtnamakaryawan.setText(nama);
        txtalamat.setText(alamat);
        txtusername.setText(username);
        txtpassword.setText(password);
        btnedit.setEnabled(true);
        btnhapus.setEnabled(true);
        txtnamakaryawan.setEnabled(true);
        cjk.setEnabled(true);
        txtalamat.setEnabled(true);
        txtusername.setEnabled(true);
        txtpassword.setEnabled(true);
        chak.setEnabled(true);
    }//GEN-LAST:event_tableMouseReleased

    private void txtalamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtalamatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtalamatActionPerformed

    private void keluarBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keluarBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_keluarBTActionPerformed

    private void txtidkaryawanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidkaryawanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidkaryawanActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncari;
    private javax.swing.JButton btnedit;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnsave;
    private javax.swing.JButton btntambah;
    private javax.swing.JComboBox<String> chak;
    private javax.swing.JComboBox<String> cjk;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField keluarBT;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtalamat;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtidkaryawan;
    private javax.swing.JTextField txtnamakaryawan;
    private javax.swing.JTextField txtpassword;
    private javax.swing.JTextField txtusername;
    // End of variables declaration//GEN-END:variables
}
