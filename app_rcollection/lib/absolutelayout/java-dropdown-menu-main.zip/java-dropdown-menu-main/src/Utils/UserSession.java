/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

/**
 *
 * @author DIMAS FEBRIAN
 */
public class UserSession {
     private static String username;
    private static String role;
    private static String id;  // Mengubah 'string' menjadi 'String'
    
    public static String getUsername() {
        return username;
    }
    
    public static void setUsername(String username) {
        UserSession.username = username;
    }
    
    public static String getRole() {
        return role;
    }
    
    public static void setRole(String role) {
        UserSession.role = role;
    }
    
    public static String getId() {
        return id;
    }
    
    public static void setId(String id) {
        UserSession.id = id;
    }
    
    // Fungsi untuk menghapus sesi pengguna
    public static void clearSession() {
        username = null;
        role = null;
        id = null;  // Menambahkan clear untuk id
    }
}