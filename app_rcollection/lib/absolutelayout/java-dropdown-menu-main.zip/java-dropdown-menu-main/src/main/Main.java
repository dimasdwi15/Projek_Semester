package main;


import Utils.UserSession;
import component.Barang;
import component.CambiaPanel;

import component.DataKaryawan;
import component.DataSupplier;
import component.DefaultForm;
import component.HomeForm;
import component.LaporanLaba;
import component.LaporanPembelian;
import component.LaporanPenjualan;
import component.TransaksiBeli;
import component.TransaksiJualAdmin;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import menu.MenuEvent;

/**
 *
 * @author RAVEN
 */
public class Main extends javax.swing.JFrame {
    int x,y;
    /**
     * Creates new form Main
     */
    
    public Main() {
        initComponents();
        //Code Menampilkan Form Home Menggunakan class method Campia Panel
        new CambiaPanel(body, new component.HomeForm());
        
        //Menampilkan Form ketika menekan Tombol Pada menu dengan melakukan Overriding Pada Method MenuEvent :Dengan Index dan subIndex sebagai Parameternya 
        menu1.setEvent(new MenuEvent() {
            @Override
            public void selected(int index, int subIndex) {
                if (index == 0) {
                    showForm(new HomeForm());
                } else if(index == 1){
                    if(subIndex==1){
                        showForm(new DataKaryawan());
                    }else if(subIndex==2){
                        showForm(new Barang());
                    }else if(subIndex==3){
                    showForm(new DataSupplier());
                    }  
                }else if(index == 2){
                        if(subIndex == 1){
                            showForm(new TransaksiJualAdmin());
                        }else if (subIndex==2){
                            showForm(new TransaksiBeli());
                        }
                        
                }else if(index==3){    
                    if(subIndex == 1){
                         showForm(new LaporanPenjualan());
                    }else if(subIndex==2){
                         showForm(new LaporanPembelian());
                    }else if(subIndex==3){
                         showForm(new LaporanLaba());
                    }else{showForm(new DefaultForm("Form : " + index + " " + subIndex));}
                }else if(index == 4 ){
                     handleLogout();
                }else {
                    showForm(new DefaultForm("Form : " + index + " " + subIndex));
                }
            }
        });
         String loggedInUser = UserSession.getUsername();
        String role = UserSession.getRole();
        String userId = UserSession.getId(); // Mengambil ID dari session

        // Tampilkan informasi pengguna
       welcomeLabel.setText("Welcome, " + loggedInUser + " (ID: " + userId + ") (" + role + ")");
    }

    //Code Menampilkan Form yang dituju 
    private void showForm(Component com) {
        body.removeAll();
        body.add(com);
        body.repaint();
        body.revalidate();
    }
    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda ingin keluar?", "Konfirmasi Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            UserSession.clearSession(); // Hapus sesi
            this.dispose(); // Tutup aplikasi
            new Login().setVisible(true); // Kembali ke login
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        scrollPaneWin111 = new scroll.ScrollPaneWin11();
        menu1 = new menu.Menu();
        body = new javax.swing.JPanel();
        welcomeLabel = new javax.swing.JLabel();
        header1 = new menu.Header();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(245, 245, 245));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(163, 163, 163)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        scrollPaneWin111.setBorder(null);
        scrollPaneWin111.setViewportView(menu1);

        jPanel1.add(scrollPaneWin111, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 98, 225, 582));

        body.setBackground(new java.awt.Color(245, 245, 245));
        body.setLayout(new java.awt.BorderLayout());
        jPanel1.add(body, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 920, 576));

        welcomeLabel.setFont(new java.awt.Font("MS Reference Sans Serif", 0, 18)); // NOI18N
        welcomeLabel.setForeground(new java.awt.Color(255, 255, 255));
        welcomeLabel.setText("jLabel1");
        jPanel1.add(welcomeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 800, 30));
        jPanel1.add(header1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1150, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel body;
    private menu.Header header1;
    private javax.swing.JPanel jPanel1;
    private menu.Menu menu1;
    private scroll.ScrollPaneWin11 scrollPaneWin111;
    private javax.swing.JLabel welcomeLabel;
    // End of variables declaration//GEN-END:variables
}
