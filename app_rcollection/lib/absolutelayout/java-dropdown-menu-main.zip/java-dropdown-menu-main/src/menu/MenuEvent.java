package menu;

/**
 *
 * @author RAVEN
 */
public interface MenuEvent {

    public void selected(int index, int subIndex);
}
